<?php
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/g5plus-widget.php' );
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/social-profile-widget.php' );
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/footer-logo-widget.php' );
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/recent-projects-widget.php' );
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/posts.php' );
include_once( PLUGIN_G5PLUS_FRAMEWORK_DIR . 'includes/widgets/twitter.php' );
