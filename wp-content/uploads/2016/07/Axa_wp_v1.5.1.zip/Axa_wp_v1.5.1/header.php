<!DOCTYPE HTML>
<!--[if IEMobile 7 ]><html class="no-js iem7" manifest="default.appcache?v=1"><![endif]--> 
<!--[if lt IE 7 ]><html class="no-js ie6" lang="en"><![endif]--> 
<!--[if IE 7 ]><html class="no-js ie7" lang="en"><![endif]--> 
<!--[if IE 8 ]><html class="no-js ie8" lang="en"><![endif]--> 
<!--[if (gte IE 9)|(gt IEMobile 7)|!(IEMobile)|!(IE)]><!-->
<html class="no-js" <?php language_attributes(); ?>><!--<![endif]-->
    <head>
        <title><?php bloginfo('name'); ?><?php wp_title('|'); ?></title>
        <meta charset="<?php bloginfo('charset'); ?>" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="description" content="AXA – Premium Responsive HTML Theme">
        <meta name="keywords" content="themes, css, html, axa, responsive, premium, forest, buy">
        <meta name="viewport" content="width=device-width, initial-scale=1.0"><!-- Remove if you're not building a responsive site. (But then why would you do such a thing?) -->
        <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css"/>
        <link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
        <link rel="shortcut icon" href="<?php echo get_stylesheet_directory_uri(); ?>/img/favicon.ico"/>
        <?php if (is_singular()) wp_enqueue_script('comment-reply'); ?>
        <?php wp_head(); ?>
        <link class="TextFont" href="" rel="stylesheet" type="text/css" />

        <script type="text/javascript" src="http://code.jquery.com/jquery-1.7.2.js"></script>
        <script type="text/javascript" src="http://jquery-ui.googlecode.com/svn/tags/latest/ui/minified/jquery-ui.min.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.cookie.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/bootstrap.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.prettyPhoto.js"></script>
        <script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/options.js"></script>
        <!-- ===== START CSS ===== -->
        <link href="<?php bloginfo('template_url'); ?>/css/bootstrap.css" rel="stylesheet" type="text/css"/>
        <link href="<?php bloginfo('template_url'); ?>/css/bootstrap-responsive.css" rel="stylesheet" type="text/css"/>
        <link href="<?php bloginfo('template_url'); ?>/css/axa.css" rel="stylesheet" type="text/css"/>
        <link href="<?php bloginfo('template_url'); ?>/css/prettyPhoto.css" rel="stylesheet" type="text/css"/>
        <!--[if IE 7]>
        <link href="<?php bloginfo('template_url'); ?>/css/ie7.css" rel="stylesheet" type="text/css"/>
        <![endif]-->
        <!--[if IE 8]>
                <link href="<?php bloginfo('template_url'); ?>/css/ie8.css" rel="stylesheet" type="text/css"/>
                <![endif]-->
        <!--[if gt IE 8]>
                <link href="<?php bloginfo('template_url'); ?>/css/ie9.css" rel="stylesheet" type="text/css"/>
                <![endif]-->
        <!-- ===== END CSS ===== -->
        <?php
        //=======get theme options from admin panel
        global $options;
        $options = get_option('axa_theme_options');
        ?> 
        <!--    get the template directory for javascript use later    -->
        <script type="text/javascript">
            var templateDir = "<?php bloginfo('template_directory') ?>";
        </script>
    </head>
    <body <?php body_class(get_theme_mod('background_texture')); ?>>
        <div class="backwrapper backwrappercolor">
            <div class="container">
                <!--  =====  START HINTS  =====  -->
                <?php if (is_front_page() && $options['tooltips']) : ?>
                    <div class="hints" id="hint1" data-index="1" data-next="2">
                        <div class="hint_arrow"></div>
                        <div class="hint_header"><span class="hint_header_title"><?php _ex('We are social','header','axa' ); ?></span><span class="hint_header_info">1/7 <a class="hint_next" href="#"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                            <div class="clear"></div>
                        </div>
                        <div class="hint_content"><?php _ex('We are social','header','axa' ); ?><?php _ex('','header','axa' ); ?>Find us on various social networks. Appreciate our activity, share our content and rate our skills!</div>
                    </div>
                    <div class="hints" id="hint2" data-index="2" data-next="3">
                        <div class="hint_arrow"></div>
                        <div class="hint_header"><span class="hint_header_title"><?php _ex('','header','axa' ); ?>Amazing Menu</span><span class="hint_header_info">2/7 <a class="hint_next" href="#"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                            <div class="clear"></div>
                        </div>
                        <div class="hint_content"><?php _ex('','header','axa' ); ?>It's very easy to navigate through the site. The dropdown menu is  intuitive and complementary with  the main menu.</div>
                    </div>
                    <div class="hints" id="hint3" data-index="3" data-next="4">
                        <div class="hint_arrow"></div>
                        <div class="hint_header"><span class="hint_header_title"><?php _ex('Awesome Wide Slider','header','axa' ); ?></span><span class="hint_header_info">3/7 <a class="hint_next" href="#"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                            <div class="clear"></div>
                        </div>
                        <div class="hint_content"><?php _ex('Add pictures to the main slider no matter how much you want. It is easy to manage your content and animate it!','header','axa' ); ?></div>
                    </div>
                    <div class="hints" id="hint4" data-index="4" data-next="5">
                        <div class="hint_arrow"></div>
                        <div class="hint_header"><span class="hint_header_title"><?php _ex('Thumbnail Carousel','header','axa' ); ?></span><span class="hint_header_info">4/7 <a class="hint_next" href="#"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                            <div class="clear"></div>
                        </div>
                        <div class="hint_content"><?php _ex('Emphasize your work with awesome CSS effects for tumbnails and autoplay feature!','header','axa' ); ?></div>
                    </div>
                    <div class="hints" id="hint5" data-index="5" data-next="6">
                        <div class="hint_arrow"></div>
                        <div class="hint_header"><span class="hint_header_title"><?php _ex('Twitter Posts','header','axa' ); ?></span><span class="hint_header_info">5/7 <a class="hint_next" href="<?php echo get_permalink(get_option('page_for_posts')) ?>"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                            <div class="clear"></div>
                        </div>
                        <div class="hint_content"><?php _ex('Find the latest tweets about us on twitter widget. Stay informed about our movements!','header','axa' ); ?></div>
                    </div>
                <?php elseif (is_home() || is_single() && $options['tooltips']) : ?>
                    <!--  =====  START HINTS & KEYBORD  =====  -->
                    <div class="keybord_mini"><img src="<?php bloginfo('template_url') ?>/img/keybord.png" alt="keybord" />
                        <div class="hints" id="hint6" data-index="6" data-next="7">
                            <div class="hint_arrow2"></div>
                            <div class="hint_header"><span class="hint_header_title"><?php _ex('Keyboard navigation','header','axa' ); ?></span><span class="hint_header_info">6/7 <a class="hint_next" href="#"><?php _ex('Next Hint','header','axa' ); ?></a><a class="hint_close" href="#"><?php _ex('Close','header','axa' ); ?></a></span>
                                <div class="clear"></div>
                            </div>
                            <div class="hint_content"><?php _ex('Navigate through the posts and add your comment with keyboard shortcuts.','header','axa' ); ?></div>
                        </div>
                    </div>
                    <div class="keybord"><img src="<?php bloginfo('template_url') ?>/img/keybord2.png" alt="keybord" /></div>
                    <div class="container">
                        <div class="hints" id="hint7" data-index="7" data-next="-1">
                            <div class="hint_arrow"></div>
                            <div class="hint_header"><span class="hint_header_title"><?php _ex('Various types of post format','header','axa' ); ?></span><span class="hint_header_info">7/7 <a class="hint_close" href="#">Close</a></span>
                                <div class="clear"></div>
                            </div>
                            <div class="hint_content"><?php _ex('Post your content on your blog, no matter what format it is: picture, video, audio or text!','header','axa' ); ?></div>
                        </div>
                    <?php endif; ?>
                    <!--  =====  END HINTS  =====  --> 

                    <!--  =====  START HEADER  =====  -->
                    <div id="header">
                        <div class="row">
                            <div class="span2">
                                <div class="logo"><a href="<?php echo home_url() ?>">
                                        <?php
                                        if ($options['logo_img'] != '') {
                                            if (have_posts()) : while (have_posts()) : the_post();
                                                    $args = array(
                                                        'post_type' => 'attachment',
                                                        'numberposts' => -1,
                                                        'orderby' => 'menu_order',
                                                        'order' => 'ASC',
                                                        'post_mime_type' => 'image',
                                                        'post_status' => null
                                                    );

                                                    $attachments = get_posts($args);
                                                    if ($attachments) {
                                                        foreach ($attachments as $attachment) {
                                                            if ($attachment->post_title == $options['logo_img']) {
                                                                ?>
                                                                <img src="<?php echo $attachment->guid ?>">
                                                                <?php
                                                                break 2;
                                                            }
                                                        }
                                                    }
                                                endwhile;
                                                rewind_posts();
                                            endif;
                                        } elseif ($options['logo_img_link'] != '')
                                            _e("<img src=" . $options['logo_img_link'] . " alt='logo' />");
                                        else
                                            _e($options['logo_text'])
                                            ?>
                                    </a>
                                </div>
                            </div>
                            <div class="span7">
                                <ul class="menu">
                                    <?php wp_nav_menu( array( 
                                        'title_li'=>'',
                                        'theme_location' => 'header-menu',
                                        'container' => false,
                                        'items_wrap' => '%3$s',
                                        'fallback_cb' => 'wp_list_pages'
                                    ) );?>
                                </ul>
                                <div class="drop_menu">
                                    <div class="btn-group"> <a class="btn dropdown-toggle" data-toggle="dropdown" href="#"> <?php _ex( 'Menu', 'header', 'axa' ); ?> <span class="caret"></span> </a>
                                        <ul class="dropdown-menu">
                                            <?php
                                            wp_list_pages($menu_arg);
                                            ?>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                            <div class="span3">
                                <?php if ($options['showsocial'] == 1) : ?>
                                    <ul class="social">
                                        <?php if ($options['show_facebook']) : ?>
                                            <li><a href="<?php _e($options['fburl']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/facebook_c.png" alt="facebook" title="Facebook"></a></li>
                                        <?php endif; ?>
                                        <?php if ($options['show_skype']) : ?>
                                            <li><a href="skype:-<?php _e($options['skype_id']) ?>-?chat"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/skype_c.png" alt="skype" title="Skype"></a></li>
                                        <?php endif; ?>
                                        <?php if ($options['show_twitter']) : ?>
                                            <li><a href="http://twitter.com/<?php _e($options['twitterid']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/twitter_c.png" alt="twitter" title="Twitter"></a></li>
                                        <?php endif; ?>
                                        <?php if ($options['show_dribble']) : ?>
                                            <li><a href="http://dribbble.com/<?php _e($options['dribble_id']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/Dribbble_c.png" alt="Dribbble" title="Dribbble"></a></li>
                                        <?php endif; ?>
                                        <?php if ($options['show_linkedin']) : ?>
                                            <li><a href="<?php _e($options['linkedin_url']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/LinkedIn_c.png" alt="LinkedIn" title="LinkedIn"></a></li>
                                                <?php endif; ?>
                                    </ul>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!--  =====  END HEADER  =====  --> 