<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?>

<?php if (!function_exists('dynamic_sidebar') || !dynamic_sidebar("sidebar")) : ?>
<?php endif; ?>
<!--  =====  START SIDEBAR  =====  -->
<div class="sidebar">
    <?php
    dynamic_sidebar("blogsidebar");
    ?>
</div>
<!--  =====  END SIDEBAR  =====  --> 
</div><!-- sidebar -->  
<div class="spacer"></div>
