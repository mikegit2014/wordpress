<?php
/*
  Template Name: AXA Portfolio Page
 */
?>
<?php get_header(); ?>
<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?> 
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<?php dynamic_sidebar('portfoliocontent') ?>
    </div>
</div>
<?php get_footer(); ?>