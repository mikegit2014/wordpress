<?php
/**
 * The template for displaying 404 pages (Not Found)
 *
 * Please see /external/starkers-utilities.php for info on get_template_parts()
 *
 * @package 	WordPress
 * @subpackage 	Starkers
 * @since 		Starkers 4.0
 */
?>
<?php get_header(); ?>
<div class="line"></div>
<div class="row">
    <div class="span5">
        <div class="error_404"><img src="<?php bloginfo('template_url') ?>/img/404.png" alt="error"/></div>
    </div>
    <div class="span7">
        <div class="error_title"><?php _ex( 'Oops! Page not found!','404','axa' ); ?></div>
        <div class="error_text"><?php _ex( 'Oops! Page not found!','404','axa' ); ?><br/>
            <?php _ex( 'If you\'re looking for something in particular, please use the search box or the sitemap below.','404','axa' ); ?></div>
        <div class="error_search">
            <?php get_search_form() ?>
        </div>
    </div>
</div>
<div class="row">
    <div class="sitemap">
        <div class="span3"><?php _ex( ' Pages ','404','axa' ); ?>
            <ul>
                <?php $pages = get_pages(); ?>
                <?php foreach ($pages as $page) : ?>
                    <li><a href="<?php echo get_permalink($page->ID) ?>"><?php echo $page->post_title ?></a></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="span3"><?php _ex( ' Categories ','404','axa' ); ?>
                <?php wp_list_categories("title_li="); ?>
        </div>
        <div class="span6"> Posts
            <ul>
                <?php
                $args = array('numberposts' => '5');
                $recent_posts = wp_get_recent_posts($args);
                foreach ($recent_posts as $recent) {
                    ?>
                    <li>
                        <a href="<?php echo get_permalink($recent["ID"]) ?>"><?php echo $recent["post_title"] ?></a>
                    </li>
                <?php }
                ?>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
    <?php dynamic_sidebar('404error'); ?>
</div>
</div>

</div>
<?php get_footer(); ?>