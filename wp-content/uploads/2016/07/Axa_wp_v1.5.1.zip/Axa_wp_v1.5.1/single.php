<?php
/**
 * Axa single post page
 */
?>
<?php get_header() ?>
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
        <!-- ===== START BLOG ===== -->
        <div class="row">
            <div class="span9">
                <div id="blog">
                    <div id="post-<?php the_ID(); ?>" class="post single">
                        <div class="post_image single">
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail();
                            }
                            ?>
                        </div>
                        <div class="post_info"> <span class="comments"><?php comments_popup_link('Leave a comment', '1 Comment', '% Comments'); ?></span> <span class="time"><?php the_date(); ?></span> <span class="dot">&bull;</span> <span class="category"><?php the_category(', '); ?></span> </div>
                        <div class="post_title"><a href="<?php echo get_permalink(); ?>"><?php the_title() ?></a></div>
                        <div class="post_text">
                            <?php the_content() ?>
                        </div>
                        <?php comments_template('', true); ?>
                    </div>
                </div>
            </div>
            <div class="span3">
                <?php get_sidebar(); ?>
            </div>
        </div>
        <!-- ===== END BLOG ===== --> 


    <?php endwhile; ?>
<?php else: ?>
    <h2>No posts to display</h2>
<?php endif; ?>
</div>
</div>
<?php get_footer(); ?>