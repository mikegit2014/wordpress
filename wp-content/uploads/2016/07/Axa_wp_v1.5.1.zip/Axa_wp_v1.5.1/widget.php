<?php

function widgetname_widget($args, $widget_args = 1) {
    extract($args, EXTR_SKIP);
    if (is_numeric($widget_args))
        $widget_args = array('number' => $widget_args);
    $widget_args = wp_parse_args($widget_args, array('number' => -1));
    extract($widget_args, EXTR_SKIP);

    $options = get_option('widgename_options');
    if (!isset($options[$number]))
        return;

    $title = $options[$number]['title'];    // single value
    $text = $options[$number]['text'];      // single value
    $check = $options[$number]['check'];       // multi value
    $radio = $options[$number]['radio'];       // single value
    $select = $options[$number]['select'];     // single value
    $textarea = $options[$number]['textarea']; // single value

    echo $before_widget; // start widget display code
    ?>
    <h2><?php echo $title
    ?></h2>
    <p><?php echo $text ?></p>
    <ul>
        <?php foreach ($check as $value) { ?>
            <li><?php echo $value ?></li>
    <?php } ?>
    </ul>
    <p><?php echo $radio ?></p>
    <p><?php echo $select ?></p>
    <p><?php echo $textarea ?></p>       
<?php echo $after_widget; // end widget display code
} // end widgetname_widget()