<?php
/*
  Template Name: AXA Full Width Page
 */
?>
<?php get_header(); ?>
<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?> 
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<?php while ( have_posts() ) : the_post(); ?>
    <?php the_content() ?>
<?php endwhile; ?>
</div>
<?php get_footer(); ?>