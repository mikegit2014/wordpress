<form class="sidesearch" method="get" role="search" action="<?php echo home_url( '/' )?>">
    <input name="s" class="search_line search_line_short" type="text" placeholder="Quick search">
    <input class="search_hidden" type="submit">
</form>