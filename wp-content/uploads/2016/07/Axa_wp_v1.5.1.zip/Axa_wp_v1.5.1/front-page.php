<?php
/*
  Template Name: AXA HomePage
 */
?>
<?php get_header(); ?>
</div>
<!--  =====  START SLIDER  =====  -->
<?php dynamic_sidebar('mainslider') ?>        
<!--  =====  END SLIDER  =====  -->

<div class="container">
    <?php if( @$mainslider ) : ?>
        <div class="line_2"></div>
    <?php endif;?>
    <?php dynamic_sidebar('maincontent') ?>
</div>
<?php get_footer(); ?>