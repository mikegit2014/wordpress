<?php
/*
  Template Name: AXA About Page
 */
?>
<?php get_header(); ?>
<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?> 
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<div id="about_us">
    <div class="row">
        <div class="span3">
            <ul id="myTab" class="tabs_menu">
                <?php
                $first = array();
                //active tab
                $active[1] = "active in";
                $active[2] = (!$options['show_aboutus_1tab'] ) ? "active in" : "";
                $active[3] = (!$options['show_aboutus_1tab'] && !$options['show_aboutus_2tab']) ? "active in" : "";
                $active[4] = (!$options['show_aboutus_1tab'] && !$options['show_aboutus_2tab'] && !$options['show_aboutus_3tab']) ? "active in" : "";
                //first tab
                $first[2] = (!$options['show_aboutus_1tab'] && $options['show_aboutus_2tab']) ? 'active first' : '';
                $first[3] = (!$options['show_aboutus_1tab'] && !$options['show_aboutus_2tab'] && $options['show_aboutus_3tab']) ? 'active first' : '';
                $first[4] = (!$options['show_aboutus_1tab'] && !$options['show_aboutus_2tab'] && !$options['show_aboutus_3tab'] && $options['show_aboutus_4tab']) ? 'active first' : '';
                ?>
                <?php if ($options['show_aboutus_1tab']) : ?>
                    <li class="active first"><a href="#1" data-toggle="tab"><?php _e($options['aboutus_1tab_title']) ?></a></li>
                <?php endif; ?>
                <?php if ($options['show_aboutus_2tab']) : ?>
                    <li class="<?php echo $first[2] ?>"><a href="#2" data-toggle="tab"><?php _e($options['aboutus_2tab_title']) ?></a></li>
                <?php endif; ?>
                <?php if ($options['show_aboutus_3tab']) : ?>
                    <li class="<?php echo $first[3] ?>"><a href="#3" data-toggle="tab"><?php _e($options['aboutus_3tab_title']) ?></a></li>
                <?php endif; ?>
                <?php if ($options['show_aboutus_4tab']) : ?>
                    <li class="<?php echo $first[4] ?>"><a href="#4" data-toggle="tab"><?php _e($options['aboutus_4tab_title']) ?></a></li>
                <?php endif; ?>
            </ul>
        </div>
        <div class="span9">
            <div id="myTabContent" class="tab-content">
                <?php for ($i = 1; $i <= 4; $i++) : ?>
                    <?php if ($options['show_aboutus_' . $i . 'tab']) : ?>
                        <div class="tab-pane fade <?php echo $active[$i] ?>" id="<?php echo $i ?>">
                            <div class="about_us_title"><?php _e($options['aboutus_' . $i . 'tab_header']) ?></div>
                            <?php
                            echo do_shortcode($options['aboutus_' . $i . 'tab_content']);
                            ?>
                            <?php if ($i == 3): ?>
                                <?php if ($options['aboutus_team_skills_title'] != '') : ?>
                                    <div class="center_title">
                                        <span>
                                            <?php echo $options['aboutus_team_skills_title'] ?>
                                        </span>
                                    </div>
                                <?php endif ?>
                                <?php if ($options["skills_nr"] > 0) : ?>
                                    <div class="row">
                                        <div class="span9">
                                            <?php for ($j = 1; $j <= $options["skills_nr"]; $j++) : ?>
                                                <div class="progress progress-striped active">
                                                    <div class="bar" style='<?php echo "width:" . $options["skill_" . $j . "_val"] . "%;" ?>'><?php echo $options["skill_" . $j] ?></div>
                                                </div>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                <?php endif ?>
                            <?php endif ?>
                        </div>
                    <?php endif; ?>
                <?php endfor; ?>
            </div>
        </div>
    </div>
    <div class="clear"></div>
</div>
<?php dynamic_sidebar('aboutcontent') ?>
</div>
<?php get_footer(); ?>