<?php

//====================Twitter===========================

function twitter_get_tweets($twitteruser){

    $cache = get_transient('belle_twitter');

    if(is_array($cache)&&array_key_exists($twitteruser, $cache))
        return $cache[$twitteruser];

    $options = get_option('axa_theme_options');
    $consumerkey = $options['twitter_consumer_key'];
    $consumersecret = $options['twitter_consumer_secret'];
    $accesstoken = $options['twitter_access_token'];
    $accesstokensecret = $options['twitter_access_tokensecret'];

    if( empty($consumerkey)||empty($consumersecret)||empty($accesstoken)||empty($accesstokensecret) )
        return null;

    $connection = getConnectionWithAccessToken($consumerkey, $consumersecret, $accesstoken, $accesstokensecret);
    $tweets = $connection->get("https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=".$twitteruser);

    if(!is_array($cache))
        $cache = array();
    $cache[$twitteruser] = $tweets;
    set_transient('belle_twitter',$cache,60);

    return $tweets;
}

function getConnectionWithAccessToken($cons_key, $cons_secret, $oauth_token, $oauth_token_secret) {
    $connection = new TwitterOAuth($cons_key, $cons_secret, $oauth_token, $oauth_token_secret);
    return $connection;
}

function linkify($status_text){
  // linkify URLs
  $status_text = preg_replace(
    '/(https?:\/\/\S+)/',
    '<a href="\1">\1</a>',
    $status_text
  );

  // linkify twitter users
  $status_text = preg_replace(
    '/(^|\s)@(\w+)/',
    '\1@<a href="http://twitter.com/\2">\2</a>',
    $status_text
  );

  // linkify tags
  $status_text = preg_replace(
    '/(^|\s)#(\w+)/',
    '\1#<a href="http://search.twitter.com/search?q=%23\2">\2</a>',
    $status_text
  );

  return $status_text;
}

function twitter_generate_output($user, $number, $callback=''){

    $tweets = twitter_get_tweets($user);
    if(is_null($tweets))
        return 'Twitter is not configured.';

    $number = min(20,$number);

    $tweets = array_slice($tweets,0,$number);

    if(!empty($callback))
        return call_user_func($callback,$tweets);

    $output = '<div class="wt_twitter">';

        $time = time();
        $last = count($tweets)-1;

        foreach($tweets as $i => $tweet){

            $date = $tweet->created_at;
            $date = date_parse($date);
            $date = mktime(0,0,0,$date['month'],$date['day'],$date['year']);
            $date = $time - $date;

            $seconds = $date%60;
            $date=floor($date/60);
            $minutes = $date%60;
            if($minutes){
                $date=floor($date/60);
                $hours = $date%24;
                if($hours){
                    $date=floor($date/24);
                    $days = $date%7;
                    if($days){
                        $date=floor($date/7);
                        $weeks = $date;
                        if($weeks)
                            $date = $weeks.' week'.(1===$weeks?'':'s').' ago';
                        else
                            $date = $days.' day'.(1===$days?'':'s').' ago';
                    }
                    else
                        $date = $hours.' hour'.(1===$hours?'':'s').' ago';
                }
                else
                    $date = $minutes.' minute'.(1===$minutes?'':'s').' ago';
            }
            else
                $date = 'less than a minute ago';

            $output .= 
            '<div class="wt_twitter_post'.($i===$last?' last':'').'">'.
                linkify($tweet->text).
                '<span class="wt_twitter_post_date">'.
                    $date.
                '</span>'.
            '</div>';

        }

    $output .= '</div>';

    return $output;
}