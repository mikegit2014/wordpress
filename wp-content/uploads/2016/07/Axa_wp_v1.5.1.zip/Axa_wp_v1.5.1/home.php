<?php
/*
  Template Name: AXA Blog Page
 */
?>
<?php get_header(); ?>
<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?> 
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<div class="row">
    <div class="span9">
        <div id="blog">
            <?php if (have_posts()): ?>
                <?php while (have_posts()) : the_post(); ?>
                    <!--  =====  START POST  =====  -->
                    <div id="post-<?php the_ID(); ?>" <?php post_class('post'); ?>>
                        <div class="post_image">
                            <?php
                            if (has_post_thumbnail()) {
                                the_post_thumbnail();
                            }
                            ?>
                        </div>
                        <div class="post_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></div>
                        <div class="post_info"><span class="comments"><?php comments_popup_link('Leave a comment', '1 Comment', '% Comments'); ?></span> <span class="time"><?php the_date(); ?></span> <span class="dot">&bull;</span> <span class="category"><?php the_category(', '); ?></span> </div>
                        <div class="post_text">
                            <?php
                            add_filter('the_content', 'strip_images', 2);
                            the_content();
                            ?>
                        </div>

                        <div class="post_link"><a href="<?php echo get_permalink(); ?>">Read More<span class="read_more_arrow"></span></a></div>
                    </div>
                    <!--  =====  END POST  =====  --> 
                <?php endwhile; ?>
            <?php else: ?>
                <h2>No posts to display</h2>
            <?php endif; ?>

            <!--  =====  START PAGINATION  =====  -->
            <div class="pagination-right pagination">
                <?php
                global $wp_query;
                $big = 999999999; // need an unlikely integer
                $total_pages = $wp_query->max_num_pages;
                if ($total_pages > 1) {
                    $current_page = max(1, get_query_var('paged'));
                    echo paginate_links(array(
                        'base' => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
                        'format' => '/page/%#%',
                        'current' => $current_page,
                        'total' => $total_pages,
                        'type' => 'list'
                    ));
                }
                ?>
            </div>
            <!--  =====  END PAGINATION  =====  --> 
        </div>
    </div>
    <div class="span3">
        <?php get_sidebar(); ?>
    </div>
</div>
<!--  =====  END BLOG  =====  -->
</div>
</div>
<?php get_footer(); ?>