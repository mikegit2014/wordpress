<?php
/**
 * Starkers functions and definitions
 *
 * For more information on hooks, actions, and filters, see http://codex.wordpress.org/Plugin_API.
 *
 * @package 	WordPress
 * @subpackage 	Starkers
 * @since 		Starkers 4.0
 */
/* ========================================================================================================================

  Required external files

  ======================================================================================================================== */

require_once( 'external/starkers-utilities.php' );

/* ========================================================================================================================

  Theme specific settings

  Uncomment register_nav_menus to enable a single menu with the title of "Primary Navigation" in your theme

  ======================================================================================================================== */

add_theme_support( 'post-thumbnails' );

// register_nav_menus(array('primary' => 'Primary Navigation'));

/* ========================================================================================================================

  Actions and Filters

  ======================================================================================================================== */

add_action( 'wp_enqueue_scripts', 'script_enqueuer' );

add_filter( 'body_class', 'add_slug_to_body_class' );

add_action('after_setup_theme', 'theme_domain');
function theme_domain(){
    load_theme_textdomain('axa', get_template_directory() . '/languages');
}

/* ========================================================================================================================

  Scripts

  ======================================================================================================================== */

/**
 * Add scripts via wp_head()
 *
 * @return void
 * @author Keir Whitaker
 */
function script_enqueuer() {
	wp_register_script( 'site', get_template_directory_uri() . '/js/site.js', array( 'jquery' ) );
	wp_enqueue_script( 'site' );

	wp_register_style( 'screen', get_template_directory_uri() . '/style.css', '', '', 'screen' );
	wp_enqueue_style( 'screen' );
}

/* ========================================================================================================================

  Comments

  ======================================================================================================================== */

/**
 * Custom callback for outputting comments
 *
 * @return void
 * @author Keir Whitaker
 */
function starkers_comment( $comment, $args, $depth ) {
	$GLOBALS[ 'comment' ] = $comment;
	?>
	<?php if ( $comment->comment_approved == '1' ): ?>
		<li>
			<article id="comment-<?php comment_ID() ?>">
				<?php echo get_avatar( $comment ); ?>
				<h4><?php comment_author_link() ?></h4>
				<time><a href="#comment-<?php comment_ID() ?>" pubdate><?php comment_date() ?> at <?php comment_time() ?></a></time>
				<?php comment_text() ?>
			</article>
			<?php
		endif;
	}

	//===========++++++includes++++++++=========================================
	include 'shortcodes.php';
	//widgets-----------
	include 'widgets/about_us_widget.php';
	include 'widgets/callus_widget.php';
	include 'widgets/gallery_widget.php';
	include 'widgets/main_slider_widget.php';
	include 'widgets/our_clients_widget.php';
	include 'widgets/recent_work_widget.php';
	include 'widgets/services_widget.php';
	include 'widgets/testimonials_widget.php';
	include 'widgets/info_widget.php';
	include 'widgets/map_address_widget.php';
	include 'widgets/recent_posts_widget.php';
	include 'widgets/recent_comments_widget.php';
	include 'widgets/categories_widget.php';
	include 'widgets/flickr_widget.php';
	include 'widgets/twitter_widget.php';

	//===========++++++End Includes++++=========================================
	/**
	 * Adding our custom fields to the $form_fields array
	 *
	 * @param array $form_fields
	 * @param object $post
	 * @return array
	 */
	function my_image_attachment_fields_to_edit( $form_fields, $post ) {
		// $form_fields is a special array of fields to include in the attachment form
		// $post is the attachment record in the database
		//     $post->post_type == 'attachment'
		// (attachments are treated as posts in WordPress)
		// add our custom field to the $form_fields array
		// input type="text" name/id="attachments[$attachment->ID][custom1]"
		$form_fields[ "custom1" ] = array(
			"label" => __( "Custom Text Field" ),
			"input" => "text", // this is default if "input" is omitted
			"value" => get_post_meta( $post->ID, "_custom1", true )
		);
		// if you will be adding error messages for your field,
		// then in order to not overwrite them, as they are pre-attached
		// to this array, you would need to set the field up like this:
		$form_fields[ "custom1" ][ "label" ] = __( "Youtube, Vimeo link for portfolio", "axa" );
		$form_fields[ "custom1" ][ "input" ] = "text";
		$form_fields[ "custom1" ][ "value" ] = get_post_meta( $post->ID, "_custom1", true );
		return $form_fields;
	}

	// attach our function to the correct hook
	add_filter( "attachment_fields_to_edit", "my_image_attachment_fields_to_edit", null, 2 );

	/**
	 * @param array $post
	 * @param array $attachment
	 * @return array
	 */
	function my_image_attachment_fields_to_save( $post, $attachment ) {
		// $attachment part of the form $_POST ($_POST[attachments][postID])
		// $post attachments wp post array - will be saved after returned
		//     $post['post_type'] == 'attachment'
		if ( isset( $attachment[ 'custom1' ] ) ) {
			// update_post_meta(postID, meta_key, meta_value);
			update_post_meta( $post[ 'ID' ], '_custom1', $attachment[ 'custom1' ] );
		}
		return $post;
	}

	add_filter( 'attachment_fields_to_save', 'my_image_attachment_fields_to_save', null, 2 );


	//content width
	if ( ! isset( $content_width ) )
		$content_width = 960;

	//Blog page


	function strip_images( $content ) {
		return preg_replace( '/<img[^>]+./', '', $content );
	}

	function cut_content( $content, $nr_chars = '200' ) {
		$str = wordwrap( $content, $nr_chars );
		$str = explode( "\n", $str );
		$str = $str[ 0 ] . '...';
		return $str;
	}

	function cut_shortcodes( $content ) {
		return preg_replace( '@\[.*?\]@', '', $content );
	}

	function no_slider( $content ) {
		return preg_replace( "@(<div class=\'slider\'.*?</div>\s*</div>\s*</div>)@is", ' ', $content );
	}

	function echo_first_image( $postID ) {
		$args = array(
			'numberposts' => 1,
			'order' => 'ASC',
			'post_mime_type' => 'image',
			'post_parent' => $postID,
			'post_status' => null,
			'post_type' => 'attachment'
		);

		$attachments = get_children( $args );

		//print_r($attachments);

		if ( $attachments ) {
			foreach ( $attachments as $attachment ) {
				$image_attributes = wp_get_attachment_image_src( $attachment->ID, 'thumbnail' ) ? wp_get_attachment_image_src( $attachment->ID, 'thumbnail' ) : wp_get_attachment_image_src( $attachment->ID, 'full' );

				echo '<img src="' . wp_get_attachment_thumb_url( $attachment->ID ) . '" class="current">';
			}
		}
	}

	//------comment form-----------------------------
	function comment_field( $field ) {
		return preg_replace( "@\n@is", " ", $field );
	}

	//===============================Sidebars===================================

	if ( function_exists( 'register_sidebar' ) ) {
		//========Blog sidebar==============
		register_sidebar( array(
			'name' => 'Blog Sidebar',
			'id' => 'blogsidebar',
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Main Slider===============
		register_sidebar( array(
			'name' => 'Home Mainslider',
			'id' => 'mainslider',
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Main Content====================
		register_sidebar( array(
			'name' => 'Home Main Content',
			'id' => 'maincontent',
			'description' => __( 'The main content area' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========About Content====================
		register_sidebar( array(
			'name' => 'About Page Content',
			'id' => 'aboutcontent',
			'description' => __( 'The about content area' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Portfolio Content====================
		register_sidebar( array(
			'name' => 'Portfolio Page Content',
			'id' => 'portfoliocontent',
			'description' => __( 'The portfolio content area' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Portfolio Content====================
		register_sidebar( array(
			'name' => 'Contact Page Content',
			'id' => 'contactcontent',
			'description' => __( 'The contact content area' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Single project Top====================
		register_sidebar( array(
			'name' => 'Single Project Top',
			'id' => 'singleproject_top',
			'description' => __( 'The top area of single project , for info and slider' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========Single project Bottom====================
		register_sidebar( array(
			'name' => 'Single Project Bottom',
			'id' => 'singleproject_bottom',
			'description' => __( 'The bottom area of single project ' ),
			'before_widget' => '',
			'after_widget' => '',
		) );
		//========404=====================================
		register_sidebar( array(
			'name' => 'Error 404 Page',
			'id' => '404error',
			'description' => __( 'The bottom content for widgets ' ),
			'before_widget' => '',
			'after_widget' => '',
			'before_title' => '',
			'after_title' => ''
		) );
	}

	//===================================Menus==================================
	function register_tt_menus() {
		register_nav_menus(
				array( 'header-menu' => __( 'Header Menu' , 'axa' ) )
		);
	}

	add_action( 'init', 'register_tt_menus' );

	//====================================Slider================================
//    include 'slider.php';
	//extras
	add_theme_support( 'post-thumbnails' );

//==============================++++++Admin Panel++++++++=======================

	function theme_options_init() {
		register_setting( 'axa_options', 'axa_theme_options' );
	}

	add_action( 'admin_init', 'theme_options_init' );

	function theme_options_add_page() {
		if ( isset( $_GET[ 'page' ] ) && $_GET[ 'page' ] == 'theme_options' ) {
			add_action( 'admin_head', 'theme_options_page_head' );
		}
		add_theme_page( __( 'AXA Theme Options', 'axa' ), __( '[AXA] Theme Options', 'axa' ), 'edit_theme_options', 'theme_options', 'theme_options_do_page' );
	}

	add_action( 'admin_menu', 'theme_options_add_page' );

	function theme_options_page_head() {


		wp_enqueue_script( 'admin', get_template_directory_uri() . '/js/bootstrap.js', array( 'jquery' ), '2.2', FALSE );
		wp_enqueue_style( 'admin', get_template_directory_uri() . '/css/bootstrap.css' );
		?>
		<link rel='stylesheet' href='<?php echo get_template_directory_uri() ?>/css/style_admin.css' type='text/css' media='all' />
		<script type="text/javascript">
			function ClipBoard()
			{
				Copied = jQuery("#exportcode");
				Copied.document.execCommand("Copy");
			}
			jQuery(document).ready(function($) {
				if (jQuery(".logo_field:eq(2)").attr('value') != '') {
					jQuery(".logo_field:eq(0),.logo_field:eq(1)").css('background-color','#f1f1f1')
				}else if(jQuery(".logo_field:eq(1)").attr('value') != ''){
					jQuery(".logo_field:eq(0)").css('background-color','#f1f1f1')
					jQuery(".logo_field:eq(1)").css('background-color','#fff')
				}else {
					jQuery(".logo_field").css('background-color','#fff')
				}
				jQuery(".logo_field").on('focusout focusin keyup', function() {
					if (jQuery(".logo_field:eq(2)").attr('value') != '') {
						jQuery(".logo_field:eq(0),.logo_field:eq(1)").css('background-color','#f1f1f1')
					}else if(jQuery(".logo_field:eq(1)").attr('value') != ''){
						jQuery(".logo_field:eq(0)").css('background-color','#f1f1f1')
						jQuery(".logo_field:eq(1)").css('background-color','#fff')
					}else {
						jQuery(".logo_field").css('background-color','#fff')
					}
				})


				jQuery('#add_skill').unbind('click').live('click', function(){
					var skills = jQuery('.skills_nr').attr("value");
					if (isNaN(skills))
						skills = 0 ;
					skills++;
					jQuery('.skills_nr').attr("value", skills)
					jQuery('#skills').before('<div class="row"><div class="span2" class="skill_order"><i>Skill '+skills+' unsaved</i></div><div class="span5"><input id="axa_theme_options[skill_'+skills+']" class="skill" type="text" name="axa_theme_options[skill_'+skills+']" /><label for="axa_theme_options[skill_'+skills+']"> Enter the skill name</label></div><div class="span3"><input id="axa_theme_options[skill_'+skills+'_val]" type="text" class="skill_val" name="axa_theme_options[skill_'+skills+'_val"] /><label for="axa_theme_options[skill_'+skills+'_val]">Enter the skill Value from 1 to 100</label></div><div class="span2"><input type="button" class="btn btn-danger remove_skill" value="Remove Skill" /></div></div>')
				})
				jQuery('.remove_skill').unbind('click').live('click', function(){
					var skills = jQuery('.skills_nr').attr("value");
					if (isNaN(skills) || skills == 0)
						skills = 1 ;
					skills--;
					jQuery('.skills_nr').attr("value", skills)
					jQuery(this).parent().parent().remove();
					// start updating attributes after removing a skill
					var i;
					i = 1;
					jQuery('.skill').each(function(){
						jQuery(this).attr({
							'id':'axa_theme_options[skill_'+i+']',
							'name':'axa_theme_options[skill_'+i+']'
						})
						i++;
					})
					var i = 1;
					jQuery('.skill_order').each(function(){
						jQuery(this).html("Skill " + i)
						i++;
					})
					var i = 1;
					jQuery('.skill_val').each(function(){
						jQuery(this).attr({
							'id':'axa_theme_options[skill_'+i+'_val]',
							'name':'axa_theme_options[skill_'+i+'_val]'
						})
						i++;
					})
					//end updating attributes after removing a skill
				})

				jQuery('form#test_form').submit(function() {
					var data = jQuery(this).serialize();
					jQuery.post(ajaxurl, data, function(response) {
						if(response == 1) {
							show_message(1);
							t = setTimeout('fade_message()', 2000);
						} else {
							show_message(2);
							t = setTimeout('fade_message()', 2000);
						}
					});
					return false;
				});

			});

			function show_message(n) {
				if(n == 1) {
					jQuery('#saved').html('<div id="message" class="updated fade"><p><strong><?php _e( 'Options saved.' ,'axa' ); ?></strong></p></div>').show();
				} else {
					jQuery('#saved').html('<div id="message" class="error fade"><p><strong><?php _e( 'Options could not be saved.' ,'axa' ); ?></strong></p></div>').show();
				}
			}

			function fade_message() {
				jQuery('#saved').fadeOut(1000);
				clearTimeout(t);
			}
		</script>
		<?php
	}

	function theme_options_do_page() {
		global $select_options;
		if ( ! isset( $_REQUEST[ 'settings-updated' ] ) )
			$_REQUEST[ 'settings-updated' ] = false;
		$options = get_option( 'axa_theme_options' );
		if ( isset( $_POST[ "import_code" ] ) ) {
			$import_code = $_POST[ 'import_code' ];
			$import_code = base64_decode( $import_code );
			$options = unserialize( $import_code );
		}
		?>
		<div>
			<?php
			screen_icon();
			echo "<h2>" . __( 'Axa Theme Options', 'axa' ) . "</h2>";
			?>
			<?php if ( false !== $_REQUEST[ 'settings-updated' ] ) : ?>
				<div>
					<p><strong><?php _e( 'Options saved', 'axa' ); ?></strong></p>
				</div>
			<?php endif; ?>
			<?php if(!tt_security_check())
            return; ?>
			<form method="post" action="options.php">
				<?php settings_fields( 'axa_options' ); ?>
				<div class="row">
					<div class="span10">
						<input class="btn btn-success" type="submit" value="<?php _e( 'Save Options', 'axa' ); ?>" />
					</div>
				</div>
				<hr />
				<div class="row" id="admin_tabs">
					<div class="span2">
						<div class="tabbable tabs-left">
							<ul id="myTab" class="nav nav-tabs">
								<li class="active first"><a href="#header" data-toggle="tab">Header</a></li>
								<li class=""><a href="#footer" data-toggle="tab">Footer</a></li>
								<li class=""><a href="#about" data-toggle="tab">About</a></li>
							</ul>
						</div>
					</div>
					<div class="span12">
						<div id="myTabContent" class="tab-content">
							<!--================================HEADER===================================-->
							<div class="tab-pane fade active in" id="header">
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Enable tooltips', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[tooltips]" name="axa_theme_options[tooltips]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'tooltips' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Website Logo', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input class="input-xlarge logo_field" id="axa_theme_options[logo_text]" type="text" name="axa_theme_options[logo_text]" value="<?php esc_attr_e( $options[ 'logo_text' ] ); ?>" >
										<label for="axa_theme_options[logo_text]"><?php _e( 'Enter yout website logo here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span10 offset2">
										<input class="input-xlarge logo_field" id="axa_theme_options[logo_img_link]" type="text" name="axa_theme_options[logo_img_link]" value="<?php esc_attr_e( $options[ 'logo_img_link' ] ); ?>" />
										<label for="axa_theme_options[logo_img_link]"><?php _e( 'Or link of image logo here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span10 offset2">
										<input class="input-xlarge logo_field" id="axa_theme_options[logo_img]" type="text" name="axa_theme_options[logo_img]" value="<?php esc_attr_e( $options[ 'logo_img' ] ); ?>" />
										<label for="axa_theme_options[logo_img]"><?php _e( 'Or caption of image logo here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span12">
										<span class="label label-info">Note :</span> If you entered the caption, it will be taken as logo ignoring the first two fields. If you entered the link, the first field will be ignored.
									</div>
								</div>
								<hr>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Display Social Bar', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[showsocial]" name="axa_theme_options[showsocial]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'showsocial' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show facebook social icon', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_facebook]" name="axa_theme_options[show_facebook]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_facebook' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Facebook URL', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[fburl]" type="text" name="axa_theme_options[fburl]" value="<?php esc_attr_e( $options[ 'fburl' ] ); ?>" />
										<label for="axa_theme_options[fburl]"><?php _e( 'Enter yout facebook profile url here http://facebook.com/yourprofileurl', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show skype social icon', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_skype]" name="axa_theme_options[show_skype]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_skype' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Skype ID', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[skype_id]" type="text" name="axa_theme_options[skype_id]" value="<?php esc_attr_e( $options[ 'skype_id' ] ); ?>" />
										<label for="axa_theme_options[skype_id]"><?php _e( 'Enter your skype nickname here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show twitter social icon', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_twitter]" name="axa_theme_options[show_twitter]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_twitter' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Twitter ID', 'axa' ); ?></b>
									</div>
									<div class="span5">
										<input id="axa_theme_options[twitterid]" type="text" name="axa_theme_options[twitterid]" value="<?php esc_attr_e( $options[ 'twitterid' ] ); ?>" />
										<label for="axa_theme_options[twitterid]"><?php _e( 'Enter your twitter username here.', 'axa' ); ?></label>
									</div>
									<div class="span5">
										<select id="axa_theme_options[tweets_nr]" type="select" name="axa_theme_options[tweets_nr]">
											<?php for ( $i = 1; $i <= 20; $i ++  ) : ?>
												<option value="<?php echo $i ?>"<?php if ( $i == $options[ 'tweets_nr' ] ) _e( ' selected="selected"' ) ?>><?php echo $i ?></option>
											<?php endfor; ?>
										</select>
										<label for="axa_theme_options[tweets_nr]"><?php _e( 'Number of latest tweets to be displayed', 'axa' ) ?></label>
									</div>
								</div>

                            	<div class="row">
                                    <div class="span9 offset2 mb10">
                                        <?php _e( "Visit <a href='https://dev.twitter.com/apps/new' target='_blank'>Twitter Apps</a> , create your App , press 'Generate Access token at the bottom', insert the following from the 'Oauth' tab." ,'belletheme' ); ?>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="span9 offset2">
                                        <input class="input-xlarge logo_field" id="axa_theme_options[twitter_consumer_key]" type="text" name="axa_theme_options[twitter_consumer_key]" value="<?php if ( ! empty( $options[ 'twitter_consumer_key' ] ) ) echo $options[ 'twitter_consumer_key' ] ; ?>" />
                                        <label for="axa_theme_options[twitter_consumer_key]"><?php _e( 'Twitter Consumer key', 'belletheme' ); ?></label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span9 offset2">
                                        <input class="input-xlarge logo_field" id="axa_theme_options[twitter_consumer_secret]" type="text" name="axa_theme_options[twitter_consumer_secret]" value="<?php if ( ! empty( $options[ 'twitter_consumer_secret' ] ) ) echo $options[ 'twitter_consumer_secret' ] ; ?>" />
                                        <label for="axa_theme_options[twitter_consumer_secret]"><?php _e( 'Twitter Consumer secret', 'belletheme' ); ?></label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span9 offset2">
                                        <input class="input-xlarge logo_field" id="axa_theme_options[twitter_access_token]" type="text" name="axa_theme_options[twitter_access_token]" value="<?php if ( ! empty( $options[ 'twitter_access_token' ] ) ) echo $options[ 'twitter_access_token' ] ; ?>" />
                                        <label for="axa_theme_options[twitter_access_token]"><?php _e( 'Twitter Access Token', 'belletheme' ); ?></label>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="span9 offset2">
                                        <input class="input-xlarge logo_field" id="axa_theme_options[twitter_access_tokensecret]" type="text" name="axa_theme_options[twitter_access_tokensecret]" value="<?php if ( ! empty( $options[ 'twitter_access_tokensecret' ] ) ) echo $options[ 'twitter_access_tokensecret' ] ; ?>" />
                                        <label for="axa_theme_options[twitter_access_tokensecret]"><?php _e( 'Twitter Access Token Secret', 'belletheme' ); ?></label>
                                    </div>
                                </div>
                                <hr>

								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show dribble social icon', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_dribble]" name="axa_theme_options[show_dribble]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_dribble' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Dribble ID', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[dribble_id]" type="text" name="axa_theme_options[dribble_id]" value="<?php esc_attr_e( $options[ 'dribble_id' ] ); ?>" />
										<label for="axa_theme_options[dribble_id]"><?php _e( 'Enter your dribble nickname here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show LinkedIn social icon', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_linkedin]" name="axa_theme_options[show_linkedin]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_linkedin' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'LinkedIn URL', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input class="input-xlarge" id="axa_theme_options[linkedin_url]" type="text" name="axa_theme_options[linkedin_url]" value="<?php esc_attr_e( $options[ 'linkedin_url' ] ); ?>" />
										<label for="axa_theme_options[linkedin_url]"><?php _e( 'Enter your LinkedIn URL here', 'axa' ); ?></label>
									</div>
								</div>
							</div>

							<!--================================FOOTER===================================-->
							<div class="tab-pane fade" id="footer">
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Flickr ID', 'axa' ); ?></b>
									</div>
									<div class="span5">
										<input id="axa_theme_options[flickrid]" type="text" name="axa_theme_options[flickrid]" value="<?php esc_attr_e( $options[ 'flickrid' ] ); ?>" />
										<label for="axa_theme_options[flickrid]"><?php _e( 'Use http://idgettr.com/ to get the flickr id of the user and paste the id here.', 'axa' ); ?></label>
									</div>
									<div class="span5">
										<select id="axa_theme_options[flickr_nr]" type="select" name="axa_theme_options[flickr_nr]">
											<?php for ( $i = 1; $i <= 20; $i ++  ) : ?>
												<option value="<?php echo $i ?>"<?php if ( $i == $options[ 'flickr_nr' ] ) _e( ' selected="selected"' ) ?>><?php echo $i ?></option>
											<?php endfor; ?>
										</select>
										<label for="axa_theme_options[flickr_nr]"><?php _e( 'Number of flickr pictures from user photostream to be displayed', 'axa' ) ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'About Us', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<textarea id="axa_theme_options[about_us]"
												  class="large-text" cols="50" rows="10" name="axa_theme_options[about_us]"><?php echo esc_textarea( $options[ 'about_us' ] ); ?></textarea>
										<label for="axa_theme_options[about_us]"><?php _e( 'Insert about us content here.', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Number of latest posts', 'axa' ); ?></b>
									</div>
									<div class="span5">
										<select id="axa_theme_options[tweets_nr]" type="select" name="axa_theme_options[nr_footer_posts]">
											<?php for ( $i = 1; $i <= 20; $i ++  ) : ?>
												<option value="<?php echo $i ?>"<?php if ( $i == $options[ 'nr_footer_posts' ] ) _e( ' selected="selected"' ) ?>><?php echo $i ?></option>
											<?php endfor; ?>
										</select>
										<label for="axa_theme_options[nr_footer_posts]"><?php _e( 'Number of latest posts.', 'axa' ) ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show Copyright Text', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_copyright]" name="axa_theme_options[show_copyright]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_copyright' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Copyright', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[copyright_text]" type="text" name="axa_theme_options[copyright_text]" value="<?php esc_attr_e( $options[ 'copyright_text' ] ); ?>" />
										<label for="axa_theme_options[copyright_text]"><?php _e( 'Enter your copyright text here', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show Footer Social', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_footer_social]" name="axa_theme_options[show_footer_social]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_footer_social' ] ); ?> />
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Show Footer Social', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[footer_social_text]" type="text" name="axa_theme_options[footer_social_text]" value="<?php esc_attr_e( $options[ 'footer_social_text' ] ); ?>" />
										<label for="axa_theme_options[footer_social_text]"><?php _e( 'Enter your social text here', 'axa' ); ?></label>
									</div>
								</div>
							</div>
							<!--================================ABOUT===================================-->
							<div class="tab-pane fade" id="about">
								<!------------------------------------about 1st tab---------------------------->
								<div class="row">
									<div class="span2">
										<b><?php _e( 'About Us Tab', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_aboutus_1tab]" name="axa_theme_options[show_aboutus_1tab]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_aboutus_1tab' ] ); ?> />
										<label for="axa_theme_options[show_aboutus_1tab]"><?php _e( 'Show tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'About Us Tab Title', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_1tab_title]" type="text" name="axa_theme_options[aboutus_1tab_title]" value="<?php esc_attr_e( $options[ 'aboutus_1tab_title' ] ); ?>" />
										<label for="axa_theme_options[aboutus_1tab_title]"><?php _e( 'Enter the title for first Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'About Us Tab Header', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_1tab_header]" type="text" name="axa_theme_options[aboutus_1tab_header]" value="<?php esc_attr_e( $options[ 'aboutus_1tab_header' ] ); ?>" />
										<label for="axa_theme_options[aboutus_1tab_header]"><?php _e( 'Enter the header for first Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'About Us Tab Content', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<textarea id="axa_theme_options[aboutus_1tab_content]"
												  class="large-text" cols="50" rows="10" name="axa_theme_options[aboutus_1tab_content]"><?php echo esc_textarea( $options[ 'aboutus_1tab_content' ] ); ?></textarea>
										<label for="axa_theme_options[aboutus_1tab_content]"><?php _e( 'Insert about us tab content here.', 'axa' ); ?></label>
									</div>
								</div>
								<hr>
								<!------------------------------------about 2nd tab---------------------------->
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Our Services Tab', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_aboutus_2tab]" name="axa_theme_options[show_aboutus_2tab]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_aboutus_2tab' ] ); ?> />
										<label for="axa_theme_options[show_aboutus_2tab]"><?php _e( 'Show tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Our Services Tab Title', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_2tab_title]" type="text" name="axa_theme_options[aboutus_2tab_title]" value="<?php esc_attr_e( $options[ 'aboutus_2tab_title' ] ); ?>" />
										<label for="axa_theme_options[aboutus_2tab_title]"><?php _e( 'Enter the title for second Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Our Services Tab Header', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_2tab_header]" type="text" name="axa_theme_options[aboutus_2tab_header]" value="<?php esc_attr_e( $options[ 'aboutus_2tab_header' ] ); ?>" />
										<label for="axa_theme_options[aboutus_2tab_header]"><?php _e( 'Enter the header for second Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Our Services Tab Content', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<textarea id="axa_theme_options[aboutus_2tab_content]"
												  class="large-text" cols="50" rows="10" name="axa_theme_options[aboutus_2tab_content]"><?php echo esc_textarea( $options[ 'aboutus_2tab_content' ] ); ?></textarea>
										<label for="axa_theme_options[aboutus_2tab_content]"><?php _e( 'Insert our services tab content here.', 'axa' ); ?></label>
									</div>
								</div>
								<hr>
								<!------------------------------------about 3rd tab---------------------------->
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Team Tab', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_aboutus_3tab]" name="axa_theme_options[show_aboutus_3tab]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_aboutus_3tab' ] ); ?> />
										<label for="axa_theme_options[show_aboutus_3tab]"><?php _e( 'Show tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Team Tab Title', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_3tab_title]" type="text" name="axa_theme_options[aboutus_3tab_title]" value="<?php esc_attr_e( $options[ 'aboutus_3tab_title' ] ); ?>" />
										<label for="axa_theme_options[aboutus_3tab_title]"><?php _e( 'Enter the title for third Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Team Tab Header', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_3tab_header]" type="text" name="axa_theme_options[aboutus_3tab_header]" value="<?php esc_attr_e( $options[ 'aboutus_3tab_header' ] ); ?>" />
										<label for="axa_theme_options[aboutus_3tab_header]"><?php _e( 'Enter the header for third Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Team Tab Content', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<textarea id="axa_theme_options[aboutus_3tab_content]"
												  class="large-text" cols="50" rows="10" name="axa_theme_options[aboutus_3tab_content]"><?php echo esc_textarea( $options[ 'aboutus_3tab_content' ] ); ?></textarea>
										<label for="axa_theme_options[aboutus_3tab_content]"><?php _e( 'Insert Team tab content here.', 'axa' ); ?></label>
									</div>
								</div>
								<hr>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'Team Skills Title', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_team_skills_title]" type="text" name="axa_theme_options[aboutus_team_skills_title]" value="<?php esc_attr_e( $options[ 'aboutus_team_skills_title' ] ); ?>" />
										<label for="axa_theme_options[aboutus_team_skills_title]"><?php _e( 'Enter the title for Team skills area', 'axa' ); ?></label>
									</div>
								</div>
								<?php if ( $options[ 'skills_nr' ] > 0 ) : ?>
									<?php for ( $i = 1; $i <= $options[ 'skills_nr' ]; $i ++  ) : ?>
										<div class="row">
											<div class="span2" class="skill_order">
												<b><?php _e( 'Skill ' . $i, 'axa' ); ?></b>
											</div>
											<div class="span5">
												<input id="axa_theme_options[skill_<?php echo $i ?>]" class="skill" type="text" name="axa_theme_options[skill_<?php echo $i ?>]" value="<?php esc_attr_e( $options[ 'skill_' . $i ] ); ?>" />
												<label><?php _e( 'Enter the skill name', 'axa' ); ?></label>
											</div>
											<div class="span3">
												<input id="axa_theme_options[skill_<?php echo $i ?>_val]" class="skill_val" type="text" name="axa_theme_options[skill_<?php echo $i ?>_val]" value="<?php esc_attr_e( $options[ 'skill_' . $i . '_val' ] ); ?>" />
												<label><?php _e( 'Enter the skill Value from 1 to 100', 'axa' ); ?></label>
											</div>
											<div class="span2">
												<input class="btn btn-danger remove_skill" type="button" value="Remove Skill" />
											</div>
										</div>
									<?php endfor; ?>
								<?php endif; ?>
								<div class="row" id="skills">
									<div class="span10 offset2">
										<input id="add_skill" class="btn btn-info" type="button" name="add_skill" value="+ Add Skill" />
										<input id="axa_theme_options[skills_nr]" class="skills_nr" type="hidden" name="axa_theme_options[skills_nr]" value="<?php esc_attr_e( $options[ 'skills_nr' ] ); ?>" />
									</div>
								</div>
								<div class="row">
									<div class="span10 offset2">
										<span class="label label-info">Note :</span>  <i>After removing a skill please save options or refresh and then continue working with skills</i>
									</div>
								</div>
								<hr>
								<!------------------------------------about 4th tab---------------------------->
								<div class="row">
									<div class="span2">
										<b><?php _e( 'FAQ Tab', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[show_aboutus_tab]" name="axa_theme_options[show_aboutus_4tab]" type="checkbox" value="1"
											   <?php checked( '1', $options[ 'show_aboutus_4tab' ] ); ?> />
										<label for="axa_theme_options[show_aboutus_4tab]"><?php _e( 'Show tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'FAQ Tab Title', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_4tab_title]" type="text" name="axa_theme_options[aboutus_4tab_title]" value="<?php esc_attr_e( $options[ 'aboutus_4tab_title' ] ); ?>" />
										<label for="axa_theme_options[aboutus_4tab_title]"><?php _e( 'Enter the title for fourth Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'FAQ Tab Header', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<input id="axa_theme_options[aboutus_4tab_header]" type="text" name="axa_theme_options[aboutus_4tab_header]" value="<?php esc_attr_e( $options[ 'aboutus_4tab_header' ] ); ?>" />
										<label for="axa_theme_options[aboutus_4tab_header]"><?php _e( 'Enter the header for fourth tab Tab', 'axa' ); ?></label>
									</div>
								</div>
								<div class="row">
									<div class="span2">
										<b><?php _e( 'FAQ Tab Content', 'axa' ); ?></b>
									</div>
									<div class="span10">
										<textarea id="axa_theme_options[aboutus_4tab_content]"
												  class="large-text" cols="50" rows="10" name="axa_theme_options[aboutus_4tab_content]"><?php echo esc_textarea( $options[ 'aboutus_4tab_content' ] ); ?></textarea>
										<label for="axa_theme_options[aboutus_4tab_content]"><?php _e( 'Insert FAQ tab content here.', 'axa' ); ?></label>
									</div>
								</div>

							</div>

							<div class="row">
								<div class="span12">
									<input class="btn btn-success btn-large" type="submit" value="<?php _e( 'Save Options', 'axa' ); ?>" />
								</div>
							</div>
						</div>
					</div>

				</div>
			</form>
			<form method="post" action="themes.php?page=theme_options">
				<div class="form-actions">
					<div class="row">
						<div class="span6">
							<span id="exportcode">
								<?php echo base64_encode( serialize( $options ) ); ?>
							</span>
							<input type="submit" id="import_button" value="Import default demo options" class="btn btn-info btn-large">
						</div>
					</div>
					<input class="input-xlarge" id="import_code" name="import_code" type="hidden" placeholder="Import Code" value="YTo0OTp7czo4OiJ0b29sdGlwcyI7czoxOiIxIjtzOjk6ImxvZ29fdGV
						   4dCI7czozMzoiQTxzcGFuPsK3PC9zcGFuPlg8c3Bhbj7Ctzwvc3Bhbj5BIjtzOjEzOiJsb2dvX2ltZ19saW5rIjtzOjA6IiI7czo4OiJsb2dvX2ltZyI7czowOiIiO3M6MTA6InNob3dzb2NpYWwiO3M6MToiMS
						   I7czoxMzoic2hvd19mYWNlYm9vayI7czoxOiIxIjtzOjU6ImZidXJsIjtzOjEwOiJ3aW5pdGhlbWVzIjtzOjEwOiJzaG93X3NreXBlIjtzOjE6IjEiO3M6ODoic2t5cGVfaWQiO3M6MTA6Indpbml0aGVtZXMiO
						   3M6MTI6InNob3dfdHdpdHRlciI7czoxOiIxIjtzOjk6InR3aXR0ZXJpZCI7czoxMDoid2luaXRoZW1lcyI7czo5OiJ0d2VldHNfbnIiO3M6MToiMyI7czoxMjoic2hvd19kcmliYmxlIjtzOjE6IjEiO3M6MTA6
						   ImRyaWJibGVfaWQiO3M6MTI6Im1pY2hhZWxzcGl0eiI7czoxMzoic2hvd19saW5rZWRpbiI7czoxOiIxIjtzOjEyOiJsaW5rZWRpbl91cmwiO3M6MTczOiJodHRwOi8vd3d3LmxpbmtlZGluLmNvbS9jb21wYW5
						   5LzQ0MTU4Nz9nb2JhY2s9JTJFbnB2XzE4MjYwNzI5Ml8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMV8qMS
						   Z0cms9cHJvZi0wLW92dy1jdXJyX3BvcyI7czo4OiJmbGlja3JpZCI7czoxMjoiMzc3Mzk1MzdATjAyIjtzOjk6ImZsaWNrcl9uciI7czoxOiI4IjtzOjg6ImFib3V0X3VzIjtzOjEzOiJBYm91dCB1cyB0ZXh0I
						   jtzOjE0OiJzaG93X2NvcHlyaWdodCI7czoxOiIxIjtzOjE0OiJjb3B5cmlnaHRfdGV4dCI7czoxNzoiUmVkLVNreSBDb3B5cmlnaHQiO3M6MTg6InNob3dfZm9vdGVyX3NvY2lhbCI7czoxOiIxIjtzOjE4OiJm
						   b290ZXJfc29jaWFsX3RleHQiO3M6MTM6IldlIGFyZSBzb2NpYWwiO3M6MTc6InNob3dfYWJvdXR1c18xdGFiIjtzOjE6IjEiO3M6MTg6ImFib3V0dXNfMXRhYl90aXRsZSI7czo4OiJBYm91dCBVcyI7czoxOTo
						   iYWJvdXR1c18xdGFiX2hlYWRlciI7czoyNDoiQWJvdXQgVXMgdGFiIEhlYWRlciBIZXJlIjtzOjIwOiJhYm91dHVzXzF0YWJfY29udGVudCI7czoyMTE6Iltyb3ddW2NvbHVtbiBzaXplPSI0Il1bYWJvdXRfc3
						   VidGl0bGVdU3ViIFRpdGxlIE5yLiAxWy9hYm91dF9zdWJ0aXRsZV1UYWIgQ29sdW1uMSBjb250ZW50IGhlcmVbL2NvbHVtbl0NCltjb2x1bW4gc2l6ZT0iNCJdW2Fib3V0X3N1YnRpdGxlXVN1YiBUaXRsZSBOc
						   i4gMlsvYWJvdXRfc3VidGl0bGVdVGFiIENvbHVtbiAyIGNvbnRlbnQgaGVyZS5bL2NvbHVtbl1bL3Jvd10iO3M6MTc6InNob3dfYWJvdXR1c18ydGFiIjtzOjE6IjEiO3M6MTg6ImFib3V0dXNfMnRhYl90aXRs
						   ZSI7czoxMjoiT3VyIFNlcnZpY2VzIjtzOjE5OiJhYm91dHVzXzJ0YWJfaGVhZGVyIjtzOjE1OiJTZXJ2aWNlcyBIZWFkZXIiO3M6MjA6ImFib3V0dXNfMnRhYl9jb250ZW50IjtzOjE4NDU6Iltyb3ddW2NvbHV
						   tbiBzaXplPSI0Il1bYWJvdXRfc3VidGl0bGVdW2ltZyBjYXB0aW9uPSJzbWFsbCBzZXJ2aWNlMSJdU3ViIFRpdGxlIE5yLiA0Wy9hYm91dF9zdWJ0aXRsZV1Gb29kIHRydWNrIGZpeGllIGxvY2F2b3JlLCBhY2
						   N1c2FtdXMgbWNzd2VlbmV5J3MgbWFyZmEgbnVsbGEgc2luZ2xlLW9yaWdpbiBjb2ZmZWUgc3F1aWQuIEV4ZXJjaXRhdGlvbiArMSBsYWJvcmUgdmVsaXQsIGJsb2cgc2FydG9yaWFsIFBCUiBsZWdnaW5ncyBuZ
						   Xh0IGxldmVsIHdlcyBhbmRlcnNvbiBhcnRpc2FuIGZvdXIgbG9rbyBmYXJtLXRvLXRhYmxlIGNyYWZ0IGJlZXIgdHdlZS5bYWJvdXRfc3VidGl0bGVdW2ltZyBjYXB0aW9uPSJzbWFsbCBzZXJ2aWNlMyJdU3Vi
						   IFRpdGxlIE5yLiA0Wy9hYm91dF9zdWJ0aXRsZV1Gb29kIHRydWNrIGZpeGllIGxvY2F2b3JlLCBhY2N1c2FtdXMgbWNzd2VlbmV5J3MgbWFyZmEgbnVsbGEgc2luZ2xlLW9yaWdpbiBjb2ZmZWUgc3F1aWQuIEV
						   4ZXJjaXRhdGlvbiArMSBsYWJvcmUgdmVsaXQsIGJsb2cgc2FydG9yaWFsIFBCUiBsZWdnaW5ncyBuZXh0IGxldmVsIHdlcyBhbmRlcnNvbiBhcnRpc2FuIGZvdXIgbG9rbyBmYXJtLXRvLXRhYmxlIGNyYWZ0IG
						   JlZXIgdHdlZS5bYWJvdXRfc3VidGl0bGVdW2ltZyBjYXB0aW9uPSJzbWFsbCBzZXJ2aWNlMiJdU3ViIFRpdGxlIE5yLiA0Wy9hYm91dF9zdWJ0aXRsZV1Gb29kIHRydWNrIGZpeGllIGxvY2F2b3JlLCBhY2N1c
						   2FtdXMgbWNzd2VlbmV5J3MgbWFyZmEgbnVsbGEgc2luZ2xlLW9yaWdpbiBjb2ZmZWUgc3F1aWQuIEV4ZXJjaXRhdGlvbiArMSBsYWJvcmUgdmVsaXQsIGJsb2cgc2FydG9yaWFsIFBCUiBsZWdnaW5ncyBuZXh0
						   IGxldmVsIHdlcyBhbmRlcnNvbiBhcnRpc2FuIGZvdXIgbG9rbyBmYXJtLXRvLXRhYmxlIGNyYWZ0IGJlZXIgdHdlZS5bL2NvbHVtbl1bY29sdW1uIHNpemU9IjQiXVthYm91dF9zdWJ0aXRsZV1baW1nIGNhcHR
						   pb249InNtYWxsIHNlcnZpY2UxIl1TdWIgVGl0bGUgTnIuIDRbL2Fib3V0X3N1YnRpdGxlXUZvb2QgdHJ1Y2sgZml4aWUgbG9jYXZvcmUsIGFjY3VzYW11cyBtY3N3ZWVuZXkncyBtYXJmYSBudWxsYSBzaW5nbG
						   Utb3JpZ2luIGNvZmZlZSBzcXVpZC4gRXhlcmNpdGF0aW9uICsxIGxhYm9yZSB2ZWxpdCwgYmxvZyBzYXJ0b3JpYWwgUEJSIGxlZ2dpbmdzIG5leHQgbGV2ZWwgd2VzIGFuZGVyc29uIGFydGlzYW4gZm91ciBsb
						   2tvIGZhcm0tdG8tdGFibGUgY3JhZnQgYmVlciB0d2VlLlthYm91dF9zdWJ0aXRsZV1baW1nIGNhcHRpb249InNtYWxsIHNlcnZpY2UzIl1TdWIgVGl0bGUgTnIuIDRbL2Fib3V0X3N1YnRpdGxlXUZvb2QgdHJ1
						   Y2sgZml4aWUgbG9jYXZvcmUsIGFjY3VzYW11cyBtY3N3ZWVuZXkncyBtYXJmYSBudWxsYSBzaW5nbGUtb3JpZ2luIGNvZmZlZSBzcXVpZC4gRXhlcmNpdGF0aW9uICsxIGxhYm9yZSB2ZWxpdCwgYmxvZyBzYXJ
						   0b3JpYWwgUEJSIGxlZ2dpbmdzIG5leHQgbGV2ZWwgd2VzIGFuZGVyc29uIGFydGlzYW4gZm91ciBsb2tvIGZhcm0tdG8tdGFibGUgY3JhZnQgYmVlciB0d2VlLlthYm91dF9zdWJ0aXRsZV1baW1nIGNhcHRpb2
						   49InNtYWxsIHNlcnZpY2UyIl1TdWIgVGl0bGUgTnIuIDRbL2Fib3V0X3N1YnRpdGxlXUZvb2QgdHJ1Y2sgZml4aWUgbG9jYXZvcmUsIGFjY3VzYW11cyBtY3N3ZWVuZXkncyBtYXJmYSBudWxsYSBzaW5nbGUtb
						   3JpZ2luIGNvZmZlZSBzcXVpZC4gRXhlcmNpdGF0aW9uICsxIGxhYm9yZSB2ZWxpdCwgYmxvZyBzYXJ0b3JpYWwgUEJSIGxlZ2dpbmdzIG5leHQgbGV2ZWwgd2VzIGFuZGVyc29uIGFydGlzYW4gZm91ciBsb2tv
						   IGZhcm0tdG8tdGFibGUgY3JhZnQgYmVlciB0d2VlLlsvY29sdW1uXVsvcm93XSI7czoxNzoic2hvd19hYm91dHVzXzN0YWIiO3M6MToiMSI7czoxODoiYWJvdXR1c18zdGFiX3RpdGxlIjtzOjQ6IlRlYW0iO3M
						   6MTk6ImFib3V0dXNfM3RhYl9oZWFkZXIiO3M6MTU6IlRlYW0gdGFiIGhlYWRlciI7czoyMDoiYWJvdXR1c18zdGFiX2NvbnRlbnQiO3M6MTI5OToiW3Jvd11bY29sdW1uIHNpemU9IjMiXVt0ZWFtX21lbWJlci
						   BuYW1lPSdKb2UgRG93ZScgcG9zaXRpb249J0NFTycgaW1nX2NhcHRpb249J0pvZScgZmFjZWJvb2s9J2h0dHA6Ly93d3cuZmFjZWJvb2suY29tL3RvbGVhYml2b2wnIHNreXBlPSd0b2xlYS1zYW1hJyBsaW5rZ
						   WRpbj0naHR0cDovL3d3dy5saW5rZWRpbi5jb20vcHViL2FuYXRvbGlpLWJpdm9sLzUxLzFhMy82MjQvJ11BY2N1c2FtdXMgbWNzd2VlbmV5J3MgbWFyZmEgbnVsbGEgc2luZ2xlLW9yaWdpbiBjb2ZmZWUgc3F1
						   aWQuIEV4ZXJjaXRhdGlvbiArMSBsYWJvcmUgdmVsaXQsIGJsb2cgc2FydG9yaWFsIFBCUiBsZWdnaW5ncyBuZXh0IGxldmVsIHdlcyBhbmRlcnNvbiBhcnRpc2FuIGZvdXIgbG9rbyBmYXJtLXRvLXRhYmxlIGN
						   yYWZ0IGJlZXIgdHdlZS5bL3RlYW1fbWVtYmVyXVsvY29sdW1uXVtjb2x1bW4gc2l6ZT0iMyJdW3RlYW1fbWVtYmVyIG5hbWU9J0pvZSBEb3dlJyBwb3NpdGlvbj0nUHJvZ3JhbW1lcicgaW1nX2NhcHRpb249J0
						   pvZTInIGZhY2Vib29rPSdodHRwOi8vd3d3LmZhY2Vib29rLmNvbS90b2xlYWJpdm9sJyBza3lwZT0ndG9sZWEtc2FtYScgbGlua2VkaW49J2h0dHA6Ly93d3cubGlua2VkaW4uY29tL3B1Yi9hbmF0b2xpaS1ia
						   XZvbC81MS8xYTMvNjI0LyddQWNjdXNhbXVzIG1jc3dlZW5leSdzIG1hcmZhIG51bGxhIHNpbmdsZS1vcmlnaW4gY29mZmVlIHNxdWlkLiBFeGVyY2l0YXRpb24gKzEgbGFib3JlIHZlbGl0LCBibG9nIHNhcnRv
						   cmlhbCBQQlIgbGVnZ2luZ3MgbmV4dCBsZXZlbCB3ZXMgYW5kZXJzb24gYXJ0aXNhbiBmb3VyIGxva28gZmFybS10by10YWJsZSBjcmFmdCBiZWVyIHR3ZWUuWy90ZWFtX21lbWJlcl1bL2NvbHVtbl1bY29sdW1
						   uIHNpemU9IjMiXVt0ZWFtX21lbWJlciBuYW1lPSdKb2UgRG93ZScgcG9zaXRpb249J01hbmFnZXInIGltZ19jYXB0aW9uPSdKb2UzJyBmYWNlYm9vaz0naHR0cDovL3d3dy5mYWNlYm9vay5jb20vdG9sZWFiaX
						   ZvbCcgc2t5cGU9J3RvbGVhLXNhbWEnIGxpbmtlZGluPSdodHRwOi8vd3d3LmxpbmtlZGluLmNvbS9wdWIvYW5hdG9saWktYml2b2wvNTEvMWEzLzYyNC8nXUFjY3VzYW11cyBtY3N3ZWVuZXkncyBtYXJmYSBud
						   WxsYSBzaW5nbGUtb3JpZ2luIGNvZmZlZSBzcXVpZC4gRXhlcmNpdGF0aW9uICsxIGxhYm9yZSB2ZWxpdCwgYmxvZyBzYXJ0b3JpYWwgUEJSIGxlZ2dpbmdzIG5leHQgbGV2ZWwgd2VzIGFuZGVyc29uIGFydGlz
						   YW4gZm91ciBsb2tvIGZhcm0tdG8tdGFibGUgY3JhZnQgYmVlciB0d2VlLlsvdGVhbV9tZW1iZXJdWy9jb2x1bW5dWy9yb3ddIjtzOjI1OiJhYm91dHVzX3RlYW1fc2tpbGxzX3RpdGxlIjtzOjEwOiJPdXIgU2t
						   pbGxzIjtzOjc6InNraWxsXzEiO3M6MTU6IldFQiBERVZFTE9QTUVOVCI7czoxMToic2tpbGxfMV92YWwiO3M6MjoiNTUiO3M6Nzoic2tpbGxfMiI7czoxNDoiR1JBUEhJQyBERVNJR04iO3M6MTE6InNraWxsXz
						   JfdmFsIjtzOjM6IjEwMCI7czo3OiJza2lsbF8zIjtzOjExOiJQSE9UT0dSQVBIWSI7czoxMToic2tpbGxfM192YWwiO3M6MjoiNzUiO3M6Nzoic2tpbGxfNCI7czo2OiJDdXN0b20iO3M6MTE6InNraWxsXzRfd
						   mFsIjtzOjI6IjQ0IjtzOjk6InNraWxsc19uciI7czoxOiI0IjtzOjE3OiJzaG93X2Fib3V0dXNfNHRhYiI7czoxOiIxIjtzOjE4OiJhYm91dHVzXzR0YWJfdGl0bGUiO3M6MzoiRkFRIjtzOjE5OiJhYm91dHVz
						   XzR0YWJfaGVhZGVyIjtzOjI2OiJGcmVxdWVudGx5IEFza2VkIFF1ZXN0aW9ucyI7czoyMDoiYWJvdXR1c180dGFiX2NvbnRlbnQiO3M6Mzg0OiJbYWNjb3JkaW9uXVthY2NvcmRpb25fdGFiIGhlYWRlcj0iRml
						   yc3QgYWNjb3JkaW9uIGhlYWRlciBoZXJlIl1Db250ZW50MVsvYWNjb3JkaW9uX3RhYl0NCiAgICAgICAgICAgICAgICAgICAgICAgIFthY2NvcmRpb25fdGFiIGhlYWRlcj0iU2Vjb25kIGFjY29yZGlvbiBoZW
						   FkZXIgaGVyZSJdQ29udGVudCAyLlsvYWNjb3JkaW9uX3RhYl0NCiAgICAgICAgICAgICAgICAgICAgICAgIFthY2NvcmRpb25fdGFiIGhlYWRlcj0iSGVhZGVyIDMgaGVyZSJdQ29udGVudCAzLlsvYWNjb3Jka
						   W9uX3RhYl0NCiAgICAgICAgICAgICAgICAgICAgICAgIFthY2NvcmRpb25fdGFiIGhlYWRlcj0iSGVhZGVyIDQgaGVyZSJdQ29udGVudCA0LlsvYWNjb3JkaW9uX3RhYl1bL2FjY29yZGlvbl0iO30=" />
					<div class="row">
						<div class="span12">
							<span class="label label-info">Note :</span>  If you pressed the "Import default demo options" button accidently just reload the page without saving the options.
						</div>
					</div>
				</div>
			</form>
			<?php
		}

		//=======Customizer=========
		function theme_customize_register( $wp_customize ) {

			//Settings--------------------
			$wp_customize->add_setting( 'site_color', array(
				'default' => '#089FC4',
				'transport' => 'refresh',
			) );
			$wp_customize->add_setting( 'footer_color', array(
				'default' => '#002028',
				'transport' => 'refresh',
			) );
			$wp_customize->add_setting( 'layout', array(
				'default' => '',
				'transport' => 'refresh',
			) );
			$wp_customize->add_setting( 'background_color', array(
				'default' => '#fff',
				'transport' => 'refresh',
			) );
			$wp_customize->add_setting( 'background_texture', array(
				'default' => '',
				'transport' => 'refresh',
			) );
			$wp_customize->add_setting( 'font', array(
				'default' => '',
				'transport' => 'refresh',
			) );

			//Sections-------------------
			$wp_customize->add_section( 'site_color', array(
				'title' => __( 'Color', 'theme' ),
				'priority' => 40,
			) );
			$wp_customize->add_section( 'background_texture', array(
				'title' => __( 'Layout & Textures', 'theme' ),
				'priority' => 30,
			) );
			$wp_customize->add_section( 'font', array(
				'title' => __( 'Text Font', 'theme' ),
				'priority' => 50,
			) );

			//Controls-------------------
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'site_color', array(
						'label' => __( 'Site Color', 'theme' ),
						'section' => 'site_color',
						'settings' => 'site_color',
							) ) );
			$wp_customize->add_control( 'layout', array(
				'label' => __( 'Site Layout', 'theme' ),
				'type' => 'select',
				'section' => 'background_texture',
				'settings' => 'layout',
				'choices' => array(
					'' => 'Full Width',
					'boxed' => 'Boxed Layout'
				)
			) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'background_color', array(
						'label' => __( 'Background Color', 'theme' ),
						'section' => 'site_color',
						'settings' => 'background_color',
							) ) );
			$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'footer_color', array(
						'label' => __( 'Footer background color', 'theme' ),
						'section' => 'site_color',
						'settings' => 'footer_color',
							) ) );
			$wp_customize->add_control( 'background_texture', array(
				'label' => __( 'Background Texture', 'theme' ),
				'section' => 'background_texture',
				'settings' => 'background_texture',
				'type' => 'radio',
				'choices' => array(
					'' => 'No Texture',
					'bodytexture01' => 'Texture 1',
					'bodytexture02' => 'Texture 2',
					'bodytexture03' => 'Texture 3',
					'bodytexture04' => 'Texture 4',
					'bodytexture05' => 'Texture 5',
					'bodytexture06' => 'Texture 6',
					'bodytexture07' => 'Texture 7',
					'bodytexture08' => 'Texture 8',
					'bodytexture09' => 'Texture 9',
					'bodytexture10' => 'Texture 10',
				),
			) );
			$wp_customize->add_control( 'font', array(
				'label' => __( 'Text Font', 'theme' ),
				'section' => 'font',
				'settings' => 'font',
				'type' => 'radio',
				'choices' => array(
					"'Open Sans', sans-serif" => "Open Sans",
					"Lato, sans-serif" => 'Lato',
					"'PT Sans Narrow, sans-serif'" => 'PT Sans Narrow',
					"Varela, sans-serif" => 'Varela',
					"'Droid-sans', sans-serif" => 'Droid sans',
					"'PT Sans Caption'" => 'PT Sans Caption',
					"Magra, sans-serif" => 'Magra',
					"Chivo, sans-serif" => 'Chivo',
					"Verdana, sans-serif" => 'Veranda',
					"Tahoma, sans-serif" => 'Tahoma',
					"Arial, sans-serif" => 'Arial',
				),
			) );
		}

		add_action( 'customize_register', 'theme_customize_register' );

		function theme_customize_css() {
			?>
			<style type="text/css">
				body {
					background-color: <?php echo '#' . get_theme_mod( 'background_color' ); ?> !important;
					font-family: <?php echo get_theme_mod( 'font' ); ?> !important
				}
				#footer{background-color:<?php echo get_theme_mod( 'footer_color' ); ?> !important;background-image: none !important;}
				a {color:<?php echo get_theme_mod( 'site_color' ) ?>}
				.post_info a {color:<?php echo get_theme_mod( 'site_color' ) ?>}
				.post_text a {color:<?php echo get_theme_mod( 'site_color' ) ?>}
				.contact_info a { color:<?php echo get_theme_mod( 'site_color' ) ?> }
				.menu > li:hover {
					padding-top:20px;
					border-top:6px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;
				}
				.menu .current_page_item {
					padding-top:20px;
					border-top:6px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;
				}
				.menu .current_page_ancestor{
					padding-top:20px !important;
					border-top:6px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;
					color:<?php echo get_theme_mod( 'site_color' ) ?> !important;
				}
				.menu li.current_page_item > a {
					color:<?php echo get_theme_mod( 'site_color' ) ?> !important;
				}
				.menu li a {
					color:#333 !important;
				}
				.menu > li > a:hover {
					color:<?php echo get_theme_mod( 'site_color' ) ?> !important;
				}

				.menu li:hover > ul > li a {
					color:#e1e1e1 !important;
					background:<?php echo get_theme_mod( 'site_color' ) ?> !important;
				}
				.menu li:hover > ul li a:hover {
					color:#fff !important;
					border:3px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;
					padding:3px 0px;
				}

				.logo span {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.services .services_title {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.callus span {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#footer .title {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#footer a {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#footer_copyright .social_footer {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#footer_copyright {border-top:1px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.Photostream .PhotostreamLink:hover {border:2px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.slide_content .slide_content_full .slide_content_box .slide_image_hover {background:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.services .services_title .services_icon:hover {border:6px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.rs_mainslider .rs_mainslider_dots_container ul.rs_mainslider_dots li.rs_mainslider_dots_active, .hover_effect {background:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.color, #about_us .about_us_sub_title, .tabs_menu li.active a, .tabs_menu li a:hover, .team .team_title span, .accordion a:hover {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#path .path_links a {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}#path .path_links a.active {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#path .path_links a:hover {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}h1, h2, h3, h4, h5, h6 {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				#blog .post .post_title a, #comment_area .comment .comment_info a, .error_title {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.sidebar .article .article_link a, .sidebar ul li a, .sidebar .twitter .wt_twitter_post a, #blog .post .post_link a, .accordion a {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.tabs_menu li.active {border-left:4px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}.porto_filter .porto_filterFilter {border-top:1px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;border-bottom:1px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.porto_filter .porto_filterFilter ul.porto_filterFilterCategories li:hover, .porto_filter .porto_filterFilter li.porto_filter_active {border-top:2px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;border-bottom:2px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.porto_filter .porto_filterFilter ul.porto_filterFilterCategories li {color:<?php echo get_theme_mod( 'site_color' ) ?> !important;}
				.sidebar .Photostream .PhotostreamLink:hover {border:1px solid <?php echo get_theme_mod( 'site_color' ) ?> !important;}
			</style>
			<script type="text/javascript">
				(function($) {
					$(document).ready( function() {
	<?php if ( get_theme_mod( 'layout' ) != '' ) : ?>
					$('#footer,#footer_copyright').addClass('backwrapper')
	<?php else : ?>
					$('#footer,#footer_copyright').removeClass('backwrapper')
	<?php endif; ?>
	<?php if ( is_single() ) : ?>
					nextpost = '<?php echo get_permalink( get_next_post( false )->ID ) ?>'
					prevpost='<?php echo get_permalink( get_previous_post( false )->ID ) ?>'
		<?php
		$posts = get_posts( 'post_type=post&orderby=rand&numberposts=1' );
		foreach ( $posts as $post ) {
			$link = get_permalink( $post );
		}
		?>
						randpost='<?php echo $link ?>'
						$(document).keypress(function(e) {
							if ($("input,textarea").is(":focus")) {
							}else{
								if(e.which == 107) {
									window.location.href = nextpost;
								}
								else if (e.which == 106) {
									window.location.href = prevpost;
								}
								else if (e.which == 99){
									$('html, body').animate({
										scrollTop: $("#commentform").offset().top
									}, 2000);
								}
								else if (e.which == 114){
									window.location.href = randpost;
								}
							}
						});

	<?php endif ?>
				$('#commentform').wrapInner('<div class="contact_form">');
			});
		})(jQuery);
			</script>
			<?php
		}

		add_action( 'wp_head', 'theme_customize_css' );

//===========================+++++Breadcrumbs+++++++========================
		function dimox_breadcrumbs() {

			$showOnHome = 1; // 1 - show breadcrumbs on the homepage, 0 - don't show
			$delimiter = '/'; // delimiter between crumbs
			$home = _x('Home','breadcrumbs','axa'); // text for the 'Home' link
			$showCurrent = 1; // 1 - show current post/page title in breadcrumbs, 0 - don't show
			$before = '<a class="active">'; // tag before the current crumb
			$after = '</a>'; // tag after the current crumb

			global $post;
			$homeLink = get_bloginfo( 'url' );

			if ( is_home() || is_front_page() ) {

				if ( $showOnHome == 1 )
					echo '<div class="path_links"><a href="' . $homeLink . '">' . $home . '</a></div>';
			} else {

				echo '<div class="path_links"><a href="' . $homeLink . '">' . $home . '</a> ' . $delimiter . ' ';

				if ( is_category() ) {
					$thisCat = get_category( get_query_var( 'cat' ), false );
					if ( $thisCat->parent != 0 )
						echo get_category_parents( $thisCat->parent, TRUE, ' ' . $delimiter . ' ' );
					echo $before . 'Archive by category "' . single_cat_title( '', false ) . '"' . $after;
				} elseif ( is_search() ) {
					echo $before . 'Search results for "' . get_search_query() . '"' . $after;
				} elseif ( is_day() ) {
					echo '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . '</a> ' . $delimiter . ' ';
					echo '<a href="' . get_month_link( get_the_time( 'Y' ), get_the_time( 'm' ) ) . '">' . get_the_time( 'F' ) . '</a> ' . $delimiter . ' ';
					echo $before . get_the_time( 'd' ) . $after;
				} elseif ( is_month() ) {
					echo '<a href="' . get_year_link( get_the_time( 'Y' ) ) . '">' . get_the_time( 'Y' ) . '</a> ' . $delimiter . ' ';
					echo $before . get_the_time( 'F' ) . $after;
				} elseif ( is_year() ) {
					echo $before . get_the_time( 'Y' ) . $after;
				} elseif ( is_single() && ! is_attachment() ) {
					if ( get_post_type() != 'post' ) {
						$post_type = get_post_type_object( get_post_type() );
						$slug = $post_type->rewrite;
						echo '<a href="' . $homeLink . '/' . $slug[ 'slug' ] . '/">' . $post_type->labels->singular_name . '</a>';
						if ( $showCurrent == 1 )
							echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
					} else {
						$cat = get_the_category();
						$cat = $cat[ 0 ];
						$cats = get_category_parents( $cat, TRUE, ' ' . $delimiter . ' ' );
						if ( $showCurrent == 0 )
							$cats = preg_replace( "#^(.+)\s$delimiter\s$#", "$1", $cats );
						echo $cats;
						if ( $showCurrent == 1 )
							echo $before . get_the_title() . $after;
					}
				} elseif ( ! is_single() && ! is_page() && get_post_type() != 'post' && ! is_404() ) {
					$post_type = get_post_type_object( get_post_type() );
					echo $before . $post_type->labels->singular_name . $after;
				} elseif ( is_attachment() ) {
					$parent = get_post( $post->post_parent );
					$cat = get_the_category( $parent->ID );
					$cat = $cat[ 0 ];
					echo get_category_parents( $cat, TRUE, ' ' . $delimiter . ' ' );
					echo '<a href="' . get_permalink( $parent ) . '">' . $parent->post_title . '</a>';
					if ( $showCurrent == 1 )
						echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
				} elseif ( is_page() && ! $post->post_parent ) {
					if ( $showCurrent == 1 )
						echo $before . get_the_title() . $after;
				} elseif ( is_page() && $post->post_parent ) {
					$parent_id = $post->post_parent;
					$breadcrumbs = array( );
					while ( $parent_id ) {
						$page = get_page( $parent_id );
						$breadcrumbs[ ] = '<a href="' . get_permalink( $page->ID ) . '">' . get_the_title( $page->ID ) . '</a>';
						$parent_id = $page->post_parent;
					}
					$breadcrumbs = array_reverse( $breadcrumbs );
					for ( $i = 0; $i < count( $breadcrumbs ); $i ++  ) {
						echo $breadcrumbs[ $i ];
						if ( $i != count( $breadcrumbs ) - 1 )
							echo ' ' . $delimiter . ' ';
					}
					if ( $showCurrent == 1 )
						echo ' ' . $delimiter . ' ' . $before . get_the_title() . $after;
				} elseif ( is_tag() ) {
					echo $before . 'Posts tagged "' . single_tag_title( '', false ) . '"' . $after;
				} elseif ( is_author() ) {
					global $author;
					$userdata = get_userdata( $author );
					echo $before . 'Articles posted by ' . $userdata->display_name . $after;
				} elseif ( is_404() ) {
					echo $before . 'Error 404' . $after;
				}

				if ( get_query_var( 'paged' ) ) {
					if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() )
						echo ' (';
					echo __( 'Page' ) . ' ' . get_query_var( 'paged' );
					if ( is_category() || is_day() || is_month() || is_year() || is_search() || is_tag() || is_author() )
						echo ')';
				}

				echo '</div>';
			}
		}

// end dimox_breadcrumbs()
require_once('php/twitteroauth/twitteroauth.php');
require_once('php/twitter.php');
//===================================TeslaSecurity Check==================================
function tt_get_username(){
    if(file_exists(get_template_directory() . '/theme_config/tt_license.txt'))
        if($username = file_get_contents(get_template_directory() . '/theme_config/tt_license.txt'))
            return base64_decode($username);
    return NULL;
}

function tt_check_username(){
    $state='';
    $username = tt_get_username();
    if ($username){
        $result = get_transient( 'security_api_result' );
        if(!$result){
				if(ini_get('allow_url_fopen')){
					$api = file_get_contents( 'http://teslathemes.com/amember/api/check-access/by-login?_key=n7RYtMjOm9qjzmiWQlta&login=' . $username);
				}
				if(empty($api) && function_exists('curl_init')){
					$api = curl_get_file_contents('http://teslathemes.com/amember/api/check-access/by-login?_key=n7RYtMjOm9qjzmiWQlta&login=' . $username);
				}
				if(!empty($api)){
					$result = json_decode($api);
					set_transient( 'security_api_result', $result, 30 * MINUTE_IN_SECONDS );
				}else{
					$state = 'no data' ;
				}
		}

        if ( !(empty($result->ok)) ){  //if username exists
            if (!empty($result->subscriptions)){    //if any active subscriptions or blocked product active
                if ( !empty($result->subscriptions->{28}) ){    //if any blocking product active
                    $state = 'blocked' ;
                }elseif(!empty($result->subscriptions->{34})){  //if any warning product active
                    $state = 'warning' ;
                }
            }
        }elseif( !in_array( $username, array( 'tt_general_user','tt_other_marketplaces_user' ) ) )
            $state = 'corrupt';

    }else
        $state = 'corrupt';
    return $state;
}

function curl_get_file_contents($URL){
    $c = curl_init();
    curl_setopt($c, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($c, CURLOPT_URL, $URL);
    $contents = curl_exec($c);
    curl_close($c);

    if ($contents) 
    	return $contents;
    else 
    	return FALSE;
}

function tt_security_check(){ // call this function somewhere in the page code to block it if account disabled on TT
    $state = tt_check_username();
    return tt_throw_errors($state);
}

function tt_throw_errors($state){
    switch ($state) {
        case 'active':
            break;
        case 'warning' :
            tt_error_message($state,true);
            break;
        case 'no data':
            tt_error_message($state,true);
            break;
        case 'blocked':
            tt_error_message($state);
            return FALSE;
        case 'corrupt':
            tt_error_message($state, NULL, "<span>Note :</span> Don't change the code or license file contents please.");
            return FALSE;
    }
    return TRUE;
}

function tt_error_message($state,$just_warning=NULL,$custom=NULL){
    echo "<div id='result_content'><div id='tt_import_alert'>";
    if ( $custom )
        echo $custom;
    if ( $just_warning )
        echo '<span>WARNING :</span> We noticed some fraudulous activity with our theme or couldn\'t connect to our servers for some reasons. Please contact us in 5 days to fix this or framework page will be blocked.<br> <span>State : ' . $state . '</span>';
    else
        echo 'The options page is <span>blocked</span> by TeslaThemes due to some <span>fraudulous action</span>.<br> Please contact us at hi@teslathemes.com or click the link below to correct your license if you think that this is a mistake. <br><span>State : ' . $state . '</span>';
    echo "</div><a href='http://teslathemes.com/contact/' class='btn'>Contact TeslaThemes</a></div>";
    return;
}