<?php
/*
  Template Name: AXA Single Project Page
 */
?>
<?php get_header(); ?>
<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?> 
<!-- ===== START PATH ===== -->
<div class="line"></div>
<div id="path">
    <div class="currentpage"><?php wp_title(''); ?></div>
    <?php if (function_exists('dimox_breadcrumbs')) dimox_breadcrumbs(); ?>
</div>
<!-- ===== END PATH ===== --> 
<?php dynamic_sidebar('singleproject_top') ?>
<div class="project">
    <?php while (have_posts()) : the_post(); ?>
        <?php the_content() ?>
    <?php endwhile; ?>
</div>
<?php dynamic_sidebar('singleproject_bottom') ?>
</div>
<?php get_footer(); ?>