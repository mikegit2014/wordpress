<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains both current comments
 * and the comment form. The actual display of comments is
 * handled by a callback to starkers_comment() which is
 * located in the functions.php file.
 *
 * @package 	WordPress
 * @subpackage 	Starkers
 * @since 		Starkers 4.0
 */
?>
<div id="comment_area">
    <?php if (post_password_required()) : ?>
        <p><?php _ex( 'This post is password protected. Enter the password to view any comments','comments','axa' ); ?></p>
    </div>

    <?php
    /* Stop the rest of comments.php from being processed,
     * but don't kill the script entirely -- we still have
     * to fully load the template.
     */
    return;
endif;
?>

<?php // You can start editing here -- including this comment! ?>

<?php if (have_comments()) : ?>
    <?php
    $comments = get_comments('post_id=' . get_the_ID());
    ?>
    <div id="comment_area">
        <div class="comment_title"><?php comments_number(); ?> <?php _ex( 'Responses to','comments','axa' ); ?> <span><?php the_title() ?></span></div>
        <?php foreach ($comments as $comment) : ?>
            <?php if ($comment->comment_parent == 0) : ?>
                <div class="comment">
                    <?php echo get_avatar( $comment, 60 );?>
                    <div class="comment_info"><span><?php echo $comment->comment_author ?></span><?php echo $comment->comment_date ?><a class="comment-reply-link" href="<?php the_permalink() ?>&amp;replytocom=<?php comment_ID() ?>#respond" onclick="return addComment.moveForm('comment-<?php comment_ID() ?>', '<?php comment_ID() ?>', 'respond', '<?php the_ID() ?>')"><?php _ex( 'Reply','comments','axa' ); ?></a></div>
                    <div class="comment_text"><?php echo $comment->comment_content ?></div>
                    <div class="clear"></div>
                </div>
                <?php $comment_parent_id = $comment->comment_ID; ?>
                <?php foreach ($comments as $comment) : ?>
                    <?php if ($comment->comment_parent == $comment_parent_id) : ?>
                        <div class="comment">
                            <div class="reply">
                                <?php echo get_avatar( $comment, 60 );?>
                                <div class="comment_info"><span><?php echo $comment->comment_author ?></span><?php echo $comment->comment_date ?><a class="comment-reply-link" href="<?php the_permalink() ?>&amp;replytocom=<?php comment_ID() ?>#respond" onclick="return addComment.moveForm('comment-<?php comment_ID() ?>', '<?php comment_ID() ?>', 'respond', '<?php the_ID() ?>')"><?php _ex( 'Reply','comments','axa' ); ?></a></div>
                                <div class="comment_text"><?php echo $comment->comment_content ?></div>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <?php $comment_parent_id2 = $comment->comment_ID; ?>
                        <?php foreach ($comments as $comment) : ?>
                            <?php if ($comment->comment_parent == $comment_parent_id2) : ?>
                                <div class="comment">
                                    <div class="reply">
                                        <div class="reply">
                                            <?php echo get_avatar( $comment, 60 );?>
                                            <div class="comment_info"><span><?php echo $comment->comment_author ?></span><?php echo $comment->comment_date ?><a class="comment-reply-link" href="<?php the_permalink() ?>&amp;replytocom=<?php comment_ID() ?>#respond" onclick="return addComment.moveForm('comment-<?php comment_ID() ?>', '<?php comment_ID() ?>', 'respond', '<?php the_ID() ?>')"><?php _ex( 'Reply','comments','axa' ); ?></a></div>
                                            <div class="comment_text"><?php echo $comment->comment_content ?></div>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                <?php endforeach; ?>
            <?php endif; ?>
        <?php endforeach; ?>
    </div>
    <?php
/* If there are no comments and comments are closed, let's leave a little note, shall we?
 * But we don't want the note on pages or post types that do not support comments.
 */
elseif (!comments_open() && !is_page() && post_type_supports(get_post_type(), 'comments')) :
    ?>

    <p><?php _ex( 'Comments are closed','comments','axa' ); ?></p>

<?php endif; ?>

<?php
$args = array(
    'fields' => apply_filters('comment_form_default_fields', array(
        'author' => '<input id="author" name="author" type="text" value="' . esc_attr($commenter['comment_author']) . '" size="30" placeholder="'.__("Name (required)","comments","AXA") .'"/>',
        'email' => '<input id="email" name="email" type="text" value="' . esc_attr($commenter['comment_author_email']) . '" size="30" placeholder="'. __("Email (required)","comments","AXA") .'"/>',
        'url' => '<input id="url" name="url" type="text" value="' . esc_attr($commenter['comment_author_url']) . '" size="30" placeholder="'. __("Website","comments","AXA") .'" />'
            )
    ),
    'comment_notes_after' => '',
    'comment_notes_before' => '',
    'title_reply' => '',
    'comment_field' => '<textarea name="comment" cols="10" rows="10" placeholder="'. __("Message ","comments","AXA") .'"></textarea>',
    'label_submit' => __('Submit Comment','axa')
);
?>
<div class="comment_title"><?php _ex( 'Leave a comment','comments','axa' ); ?></div>
<div class="contact_form">
    <?php
    comment_form($args);
    ?>
</div>
</div><!-- #comments -->
