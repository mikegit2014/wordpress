<?php
//=======get theme options from admin panel
global $options;
$options = get_option('axa_theme_options');
?>
</div>
<!--  =====  START FOOTER  =====  -->
<div id="footer">
    <div id="footer_arrow"><a href="#header"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/ontop_arrow.png" alt="ontop" title="To the top" ></a></div>
    <div class="container">
        <div class="row">
            <div class="span4">
                <div class="title"><?php _ex( 'About us','footer','axa' ); ?></div>
                <?php echo $options["about_us"] ?>
            </div>
            <div class="span4">
                <div class="title"><?php _e('Latest blog posts','axa') ?></div>
                <?php
                $args = array('numberposts' => $options['nr_footer_posts']);
                $recent_posts = wp_get_recent_posts($args);
                foreach ($recent_posts as $recent) {
                    $image = get_bloginfo('template_url') . '/img/icons/comment_author.png';
                    if (has_post_thumbnail($recent["ID"])) {
                        $image = wp_get_attachment_image_src(get_post_thumbnail_id($recent["ID"], array('50', '36')), 'single-post-thumbnail');
                        $image = $image[0];
                    }
                    ?>
                    <div class="footer_posts">
                        <div class="image"><img src="<?php echo $image ?>" alt="latest blog image"></div>
                        <div class="footer_posts_title"><?php echo '<a href="' . get_permalink($recent["ID"]) . '" title="Look ' . esc_attr($recent["post_title"]) . '" >' . $recent["post_title"] . '</a>'; ?>
                        </div>
                        <span><?php echo mysql2date('j.m.y', $recent["post_date"]); ?></span>
                        <div class="clear"></div>
                    </div>
                <?php }
                ?>
            </div>

            <div class="span4">
                <div class="title"><?php _e('Latest Tweets','axa') ?></div>
                <?php if (isset($options['twitterid']) && isset($options['tweets_nr']))echo twitter_generate_output($options['twitterid'], $options['tweets_nr']); ?>
                <div class="title"><?php _e('Flickr','axa') ?></div>
                <div class="Photostream" data-userid="<?php _e($options['flickrid']) ?>" data-items="<?php _e($options['flickr_nr']) ?>"></div>
            </div>
        </div>
    </div>
</div>

<div id="footer_copyright">
    <div class="container">
        <?php if ($options['show_copyright'] == 1) : ?>
            <span class="copyright"><?php _e($options['copyright_text']) ?></span>
        <?php endif; ?>
        <?php if ($options['show_footer_social'] == 1) : ?>
            <span class="social_footer"><?php _e($options['footer_social_text']) ?>
                <a href="<?php _e($options['fburl']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/facebook_c.png" alt="facebook" title="Facebook"></a>
                <?php if ($options['show_skype']) : ?>
                    <a href="skype:-<?php _e($options['skype_id']) ?>-?chat"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/skype_c.png" alt="skype" title="Skype"></a>
                <?php endif; ?>
                <?php if ($options['show_twitter']) : ?>
                    <a href="http://twitter.com/<?php _e($options['twitterid']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/twitter_c.png" alt="twitter" title="Twitter"></a>
                <?php endif; ?>
                <?php if ($options['show_dribble']) : ?>
                    <a href="http://dribbble.com/<?php _e($options['dribble_id']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/Dribbble_c.png" alt="Dribbble" title="Dribbble"></a>
                <?php endif; ?>
                <?php if ($options['show_linkedin']) : ?>
                    <a href="<?php _e($options['linkedin_url']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/LinkedIn_c.png" alt="LinkedIn" title="LinkedIn"></a>
                    <?php endif; ?>
                <?php endif; ?>
    </div>

    <!--  =====  END FOOTER  =====  -->
    <?php wp_footer(); ?>
</body>
</html>
