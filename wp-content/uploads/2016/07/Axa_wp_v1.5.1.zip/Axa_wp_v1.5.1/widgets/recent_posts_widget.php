<?php
/*
  Plugin Name: RecentPostsAxa
  Plugin URI: http://red-sky.pl/
  Description: Displays RecentPostsAxa list
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class RecentPostsAxaWidget extends WP_Widget {

    function RecentPostsAxaWidget() {
        $widget_ops = array('classname' => 'RecentPostsAxaWidget', 'description' => 'Displays Recent Posts list of links');
        $this->WP_Widget('RecentPostsAxaWidget', '[AXA] Recent Posts Axa', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('title' => 'Latest Articles', 'nr_posts' => 3));
        $title = $instance['title'];
        $nr_posts = $instance['nr_posts'];
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="title" value="<?php echo esc_attr($title); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('nr_posts'); ?>">Nr of posts to show: <input class="widefat" id="<?php echo $this->get_field_id('nr_posts'); ?>" name="<?php echo $this->get_field_name('nr_posts'); ?>" type="title" value="<?php echo esc_attr($nr_posts); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['nr_posts'] = $new_instance['nr_posts'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? 'Latest Articles' : $instance['title'];
        $nr_posts = empty($instance['nr_posts']) ? 3 : $instance['nr_posts'];
        echo $before_widget;
        ?>
        <div class="sidebar_title"><?php echo $title ?></div>
        <div class="articles">
            <?php
            $args = array('numberposts' => $nr_posts);
            $recent_posts = wp_get_recent_posts($args);
            foreach ($recent_posts as $recent) {
                $image = get_bloginfo('template_url') . '/img/icons/comment_author.png';
                if (has_post_thumbnail($recent["ID"])) {
                    $image = wp_get_attachment_image_src(get_post_thumbnail_id($recent["ID"], array('50', '36')), 'single-post-thumbnail');
                    $image = $image[0];
                }
                ?>
                <div class="article">
                    <div class="article_image"><img src="<?php echo $image ?>" alt="article_image" /></div>
                    <div class="article_text"><?php echo cut_shortcodes(cut_content(strip_images($recent['post_content']), 100));?></div>
                    <div class="article_link"><a href="<?php echo get_permalink($recent["ID"]) ?>"><?php _ex( 'Read More ','recent-posts','axa' ); ?>></a></div>
                </div>
            <?php } ?>
        </div>
        <?php
        echo $after_widget;
    }
}

add_action('widgets_init', create_function('', 'return register_widget("RecentPostsAxaWidget");'));