<?php
/*
  Plugin Name: Gallery
  Plugin URI: http://red-sky.pl/
  Description: Displays a gallery with images and filters/links
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class GalleryWidget extends WP_Widget {

    function GalleryWidget() {
        $widget_ops = array('classname' => 'GalleryWidget', 'description' => 'Displays a gallery with images and filters/links');
        $this->WP_Widget('GalleryWidget', '[AXA] Gallery widget for portfolio', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('caption' => '', 'filters' => ''));
        $caption = $instance['caption'];
        $filters = $instance['filters'];
        ?>
        <p><label for="<?php echo $this->get_field_id('caption'); ?>">Image Caption Used for gallery: <input class="widefat" id="<?php echo $this->get_field_id('caption'); ?>" name="<?php echo $this->get_field_name('caption'); ?>" type="text" value="<?php echo esc_attr($caption); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('filters'); ?>">Filter names,separated by comas , from alternate text of images: <input class="widefat" id="<?php echo $this->get_field_id('filters'); ?>" name="<?php echo $this->get_field_name('filters'); ?>" type="text" value="<?php echo esc_attr($filters); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['caption'] = $new_instance['caption'];
        $instance['filters'] = $new_instance['filters'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $caption = $instance['caption'];
        $tmp = $instance['filters'];
        $filters = explode(',', $tmp);
        if (!empty($caption) && !empty($filters)) {
            $filter_nr = 1;
            echo $before_widget;
            ?>
            <div class="porto_filter">
                <div class="porto_filterFilter">
                    <div class="center">
                        <ul class="porto_filterFilterCategories">
                            <?php foreach ($filters as $filter) : ?>
                                <li<?php if ($filter_nr == 1) _e(' class="porto_filter_active"') ?> data-category="<?php _e($filter) ?>"><?php _e($filter) ?></li>
                                <?php $filter_nr++; ?>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <div class="porto_filterContainer">
                    <?php
                    if (have_posts()) : while (have_posts()) : the_post();
                            $args = array(
                                'post_type' => 'attachment',
                                'numberposts' => -1,
                                'orderby' => 'menu_order',
                                'order' => 'ASC',
                                'post_mime_type' => 'image',
                                'post_status' => null,
                            );
                            $attachments = get_posts($args);
                            if ($attachments) {
                                foreach ($attachments as $attachment) {
                                    if ($attachment->post_excerpt == $caption) {
										$video_link = get_post_meta( $attachment->ID, "_custom1", true );
										$link = (isset($video_link) && $video_link!='')? $video_link : $attachment->guid;
                                        ?>
                                        <div class="porto_box" data-categories="<?php echo get_post_meta($attachment->ID, '_wp_attachment_image_alt', true); ?>">
                                            <div class="porto_image">
                                                <div class="hover_effect">
                                                    <div class="image_zoom"><a href="<?php echo $link ?>" data-rel="prettyPhoto" title="<?php echo $attachment->post_title ?>"><img src="<?php bloginfo('template_url'); ?>/img/image_zoom.png" alt="zoom"/></a></div>
                                                    <div class="porto_title"><a href="<?php echo get_permalink($attachment->post_parent); ?>"><?php echo $attachment->post_title ?></a></div>
                                                    <div class="porto_type"><?php echo $attachment->post_content ?></div>
                                                </div>
                                                <img src="<?php echo $attachment->guid ?>" alt="portfolio" />
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            }
                        endwhile;
                    endif;
                    ?>
                </div>
            </div>
            <?php
            echo $after_widget;
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("GalleryWidget");'));