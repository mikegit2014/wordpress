<?php
/*
  Plugin Name: About Us Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays about us text
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class AboutUsWidget extends WP_Widget {

    function AboutUsWidget() {
        $widget_ops = array('classname' => 'AboutUsWidget', 'description' => 'Displays about us text');
        $this->WP_Widget('AboutUsWidget', '[AXA] About us text', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('text' => ''));
        $text = $instance['text'];
        ?>
        <p><label for="<?php echo $this->get_field_id('text'); ?>">About Us Text: <input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" type="text" value="<?php echo esc_attr($text); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['text'] = $new_instance['text'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);

        $text = empty($instance['text']) ? ' ' : apply_filters('widget_text', $instance['text']);

        if (!empty($text)) {
            echo $before_widget;
            echo $text;
            echo $after_widget;
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("AboutUsWidget");'));