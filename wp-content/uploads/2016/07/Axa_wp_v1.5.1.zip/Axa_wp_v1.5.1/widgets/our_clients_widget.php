<?php
/*
  Plugin Name: Our Clients Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays our clients slider
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class OurClientsWidget extends WP_Widget {

    function OurClientsWidget() {
        $widget_ops = array('classname' => 'OurClientsWidget', 'description' => 'Displays our clients slider');
        $this->WP_Widget('OurClientsWidget', '[AXA] Our Clients slider', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('hook' => ''));
        $hook = $instance['hook'];
        ?>
        <p><label for="<?php echo $this->get_field_id('hook'); ?>">Caption of image to be used in our clients slider: <input class="widefat" id="<?php echo $this->get_field_id('hook'); ?>" name="<?php echo $this->get_field_name('hook'); ?>" type="text" value="<?php echo esc_attr($hook); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['hook'] = $new_instance['hook'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $hook = empty($instance['hook']) ? ' ' : apply_filters('widget_hook', $instance['hook']);
        if (!empty($hook)) {
            ?>
            <div class="center_title"><span><i class="icon-chevron-left slide_nav_back"></i> Our Clients <i class="icon-chevron-right slide_nav_next"></i></span></div>
            <div class="slide_content">
                <div class="row slide_content_show">
                    <div class="slide_content_full">
                        <?php
                        if (have_posts()) : while (have_posts()) : the_post();
                                $args = array(
                                    'post_type' => 'attachment',
                                    'numberposts' => -1,
                                    'orderby' => 'menu_order',
                                    'order' => 'ASC',
                                    'post_mime_type' => 'image',
                                    'post_status' => null,
                                );
                                $attachments = get_posts($args);
                                if ($attachments) {
                                    foreach ($attachments as $attachment) {
                                        if ($attachment->post_excerpt == $hook) {
                                            ?>
                                            <div class="span2">
                                                <div class="slide_content_box">
                                                    <a href="<?php echo get_permalink($attachment->post_parent); ?>">
                                                        <img src="<?php echo $attachment->guid?>" alt="client" />
                                                    </a>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                }
                            endwhile;
                        endif;
                        ?>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("OurClientsWidget");'));