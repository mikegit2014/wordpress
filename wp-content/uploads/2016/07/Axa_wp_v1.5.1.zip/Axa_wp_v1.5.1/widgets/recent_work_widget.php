<?php
/*
  Plugin Name: Recent Work Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays Recent Work slider
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class RecentWorkWidget extends WP_Widget {

    function RecentWorkWidget() {
        $widget_ops = array('classname' => 'RecentWorkWidget', 'description' => 'Displays Recent Work slider');
        $this->WP_Widget('RecentWorkWidget', '[AXA] Recent Work slider', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('hook' => '','title'=>''));
        $hook = $instance['hook'];
        $title = $instance['title'];
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title for the slider: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('hook'); ?>">Caption of image to be used in Recent Work slider: <input class="widefat" id="<?php echo $this->get_field_id('hook'); ?>" name="<?php echo $this->get_field_name('hook'); ?>" type="text" value="<?php echo esc_attr($hook); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['hook'] = $new_instance['hook'];
        $instance['title'] = $new_instance['title'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? '' : $instance['title'];
        $hook = empty($instance['hook']) ? ' ' : apply_filters('widget_hook', $instance['hook']);
        if (!empty($hook)) {
            ?>
            <div class="center_title"><span><i class="icon-chevron-left slide_nav_back"></i><?php echo $title ?><i class="icon-chevron-right slide_nav_next"></i></span></div>
            <div class="slide_content">
                <div class="row slide_content_show">
                    <div class="slide_content_full">
                        <?php
                        if (have_posts()) : while (have_posts()) : the_post();
                                $args = array(
                                    'post_type' => 'attachment',
                                    'numberposts' => -1,
                                    'orderby' => 'menu_order',
                                    'order' => 'ASC',
                                    'post_mime_type' => 'image',
                                    'post_status' => null,
                                );
                                $attachments = get_posts($args);
                                if ($attachments) {
                                    foreach ($attachments as $attachment) {
                                        if ($attachment->post_excerpt == $hook) {
                                            ?>
                                            <div class="span3">
                                                <div class="slide_content_box">
                                                    <div class="slide_image_hover">
                                                        <div class="slide_center">
                                                            <div class="slide_image_zoom"> <a href="<?php echo $attachment->guid ?>" data-rel="prettyPhoto" title="Project image"><img src="<?php bloginfo('template_url'); ?>/img/image_zoom.png" alt="zoom"/></a> </div>
                                                            <div class="slide_image_link"> <a href="<?php echo get_permalink($attachment->post_parent); ?>" title="Project link"><img src="<?php bloginfo('template_url'); ?>/img/image_link.png" alt="link"/></a> </div>
                                                        </div>
                                                    </div>
                                                    <div class="slide_image"><img src="<?php echo $attachment->guid ?>" alt="carouselimage"/></div>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                }
                            endwhile;
                        endif;
                        ?>
                        <div class="clear"></div>
                    </div>
                </div>
            </div>
            <?php
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("RecentWorkWidget");'));