<?php
/*
  Plugin Name: RecentCommentsAxa
  Plugin URI: http://red-sky.pl/
  Description: Displays RecentCommentsAxa list
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class RecentCommentsAxaWidget extends WP_Widget {

    function RecentCommentsAxaWidget() {
        $widget_ops = array('classname' => 'RecentCommentsAxaWidget', 'description' => 'Displays Recent Comments list');
        $this->WP_Widget('RecentCommentsAxaWidget', '[AXA] Recent Comments Axa', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('title' => 'Recent Comments', 'nr_comments' => 5));
        $title = $instance['title'];
        $nr_comments = $instance['nr_comments'];
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="title" value="<?php echo esc_attr($title); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('nr_comments'); ?>">Nr of comments to show: <input class="widefat" id="<?php echo $this->get_field_id('nr_comments'); ?>" name="<?php echo $this->get_field_name('nr_comments'); ?>" type="title" value="<?php echo esc_attr($nr_comments); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['nr_comments'] = $new_instance['nr_comments'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? 'Latest Articles' : $instance['title'];
        $nr_comments = empty($instance['nr_comments']) ? 3 : $instance['nr_comments'];
        echo $before_widget;
        ?>
        <div class="sidebar_title"><?php echo $title ?></div>
        <?php
        $recent_comments = get_comments(array(
            'number' => $nr_comments,
            'status' => 'approve'
                ));
        ?>
        <ul class="recent_comments">
            <?php foreach ($recent_comments as $recent_comment) : ?>
                <li><?php echo $recent_comment->comment_author ?><?php _ex( ' on ','recent-comments','axa' ); ?><a href="<?php echo get_permalink($recent_comment->comment_post_ID) ?>"><?php echo cut_content(strip_images(get_post($recent_comment->comment_post_ID)->post_content), 20) ?></a></li>
            <?php endforeach; ?>
        </ul>
        <?php
        echo $after_widget;
    }
}

add_action('widgets_init', create_function('', 'return register_widget("RecentCommentsAxaWidget");'));