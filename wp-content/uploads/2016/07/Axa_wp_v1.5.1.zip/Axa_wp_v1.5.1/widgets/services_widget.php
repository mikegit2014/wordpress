<?php
/*
  Plugin Name: Services Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays services
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class ServicesWidget extends WP_Widget {

    function ServicesWidget() {
        $widget_ops = array('classname' => 'ServicesWidget', 'description' => 'Displays Services');
        $this->WP_Widget('ServicesWidget', '[AXA] Services', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('hook' => ''));
        $hook = $instance['hook'];
        ?>
        <p><label for="<?php echo $this->get_field_id('hook'); ?>">Caption of images used for services: <input class="widefat" id="<?php echo $this->get_field_id('hook'); ?>" name="<?php echo $this->get_field_name('hook'); ?>" type="text" value="<?php echo esc_attr($hook); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['hook'] = $new_instance['hook'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $hook = empty($instance['hook']) ? ' ' : apply_filters('widget_hook', $instance['hook']);
        if (!empty($hook)) {
            ?>
            <div class="services">
                <div class="row">
                    <?php
                            $args = array(
                                'post_type' => 'attachment',
                                'numberposts' => -1,
                                'orderby' => 'menu_order',
                                'order' => 'ASC',
                                'post_mime_type' => 'image',
                                'post_status' => null,
                            );
                            $attachments = get_posts($args);
                            if ($attachments) {
                                $num_services = 0;
                                $total_services = 0;
                                foreach ($attachments as $attachment)
                                    if ($attachment->post_excerpt == $hook)
                                        $total_services++;
                                $size = ($total_services > 4) ? 3 : 12 / $total_services;
                                foreach ($attachments as $attachment) {
                                    if ($attachment->post_excerpt == $hook) {
                                        $num_services++;
                                        if ($num_services > 4)
                                            break;
                                        ?>
                                        <div class="span<?php echo $size ?>">
                                            <div class="services_title">
                                                <div class="services_icon"><a href="<?php echo get_permalink($attachment->post_parent); ?>"><img src="<?php echo $attachment->guid ?>" alt="service"/></a></div>
                                                    <?php if ($attachment->post_title != "") : ?>
                                                    <span><a href="<?php echo get_permalink($attachment->post_parent); ?>"><?php echo $attachment->post_title ?></a></span>
                                                <?php endif; ?>
                                            </div>
                                            <p>
                                                <?php if ($attachment->post_content != "") : ?>
                                                    <span><?php echo $attachment->post_content ?></span>
                                                <?php endif; ?>
                                            </p>
                                        </div>
                                        <?php
                                    }
                                }
                            }
                    ?>
                </div>
            </div>
            <?php
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("ServicesWidget");'));