<?php
/*
  Plugin Name: Flickr
  Plugin URI: http://red-sky.pl/
  Description: Displays Flickr images
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class FlickrWidget extends WP_Widget {

    function FlickrWidget() {
        $widget_ops = array('classname' => 'FlickrWidget', 'description' => 'Displays Recent flickr account images');
        $this->WP_Widget('FlickrWidget', '[AXA] Flickr', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('title' => 'Flickr Gallery', 'nr_images' => 9, 'flickr_id'=>'37739537@N02'));
        $title = $instance['title'];
        $nr_images = $instance['nr_images'];
        $flickr_id = $instance['flickr_id'];
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="title" value="<?php echo esc_attr($title); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('nr_images'); ?>">Nr of images to show in photostream: <input class="widefat" id="<?php echo $this->get_field_id('nr_images'); ?>" name="<?php echo $this->get_field_name('nr_images'); ?>" type="title" value="<?php echo esc_attr($nr_images); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('flickr_id'); ?>">Flickr ID. Use http://idgettr.com/ to get the flickr id of the user and paste the id here. <input class="widefat" id="<?php echo $this->get_field_id('flickr_id'); ?>" name="<?php echo $this->get_field_name('flickr_id'); ?>" type="title" value="<?php echo esc_attr($flickr_id); ?>" /></label></p>

        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['nr_images'] = $new_instance['nr_images'];
        $instance['flickr_id'] = $new_instance['flickr_id'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? 'Flickr Gallery' : $instance['title'];
        $nr_images = empty($instance['nr_images']) ? 9 : $instance['nr_images'];
        $flickr_id = empty($instance['flickr_id']) ? 9 : $instance['flickr_id'];
        echo $before_widget;
        ?>
        <div class="sidebar_title"><?php echo $title ?></div>
        <div class="Photostream" data-userid="<?php echo $flickr_id ?>" data-items="<?php echo $nr_images ?>"></div>
        <?php
        echo $after_widget;
    }

}

add_action('widgets_init', create_function('', 'return register_widget("FlickrWidget");'));