<?php
/*
  Plugin Name: MapAddr
  Plugin URI: http://red-sky.pl/
  Description: Displays a map with detailed address
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class MapAddrWidget extends WP_Widget {

    function MapAddrWidget() {
        $widget_ops = array('classname' => 'MapAddrWidget', 'description' => 'Displays a map with detailed address and a contact form with data validation');
        $this->WP_Widget('MapAddrWidget', '[AXA] Map with address and Contact form', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('email'=>'','add_one' => '', 'add_two' => '', 'show_form' => false, 'show_addr' => false, 'show_map' => true, 'map' => ''));
        $map = $instance['map'];
        $add_one = $instance['add_one'];
        $add_two = $instance['add_two'];
        $show_map = $instance['show_map'];
        $show_form = $instance['show_form'];
        $show_addr = $instance['show_addr'];
        $phone = $instance['phone'];
        $fax = $instance['fax'];
        $email = $instance['email'];
        $website = $instance['website'];
        ?>
        <p><label for="<?php echo $this->get_field_id('show_map'); ?>"><input id="<?php echo $this->get_field_id('show_map'); ?>" name="<?php echo $this->get_field_name('show_map'); ?>" type="checkbox" value="1" <?php checked('1', $show_map); ?>/> Show Google Map</label></p>
        <p><label for="<?php echo $this->get_field_id('map'); ?>"><textarea cols="40" rows="15" id="<?php echo $this->get_field_id('map'); ?>" name="<?php echo $this->get_field_name('map'); ?>"><?php _e($map) ?></textarea> Google Map Embed (get it from maps.google.com)</label></p>
        <p><label for="<?php echo $this->get_field_id('show_form'); ?>"><input id="<?php echo $this->get_field_id('show_form'); ?>" name="<?php echo $this->get_field_name('show_form'); ?>" type="checkbox" value="1" <?php checked('1', $show_form); ?>/> Show contact form </label></p>
        <p><label for="<?php echo $this->get_field_id('show_addr'); ?>"><input id="<?php echo $this->get_field_id('show_addr'); ?>" name="<?php echo $this->get_field_name('show_addr'); ?>" type="checkbox" value="1" <?php checked('1', $show_addr); ?>/> Show address and Info</label></p>
        <p><label for="<?php echo $this->get_field_id('add_one'); ?>">Address 1: <input class="widefat" id="<?php echo $this->get_field_id('add_one'); ?>" name="<?php echo $this->get_field_name('add_one'); ?>" type="text" value="<?php echo esc_attr($add_one); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('add_two'); ?>">Address 2: <input class="widefat" id="<?php echo $this->get_field_id('add_two'); ?>" name="<?php echo $this->get_field_name('add_two'); ?>" type="text" value="<?php echo esc_attr($add_two); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('phone'); ?>">Phone: <input class="widefat" id="<?php echo $this->get_field_id('phone'); ?>" name="<?php echo $this->get_field_name('phone'); ?>" type="text" value="<?php echo esc_attr($phone); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('fax'); ?>">Fax: <input class="widefat" id="<?php echo $this->get_field_id('fax'); ?>" name="<?php echo $this->get_field_name('fax'); ?>" type="text" value="<?php echo esc_attr($fax); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('email'); ?>">Email: <input class="widefat" id="<?php echo $this->get_field_id('email'); ?>" name="<?php echo $this->get_field_name('email'); ?>" type="text" value="<?php echo esc_attr($email); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('website'); ?>">WebSite: <input class="widefat" id="<?php echo $this->get_field_id('website'); ?>" name="<?php echo $this->get_field_name('website'); ?>" type="text" value="<?php echo esc_attr($website); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['add_one'] = $new_instance['add_one'];
        $instance['add_two'] = $new_instance['add_two'];
        $instance['show_map'] = $new_instance['show_map'];
        $instance['map'] = $new_instance['map'];
        $instance['show_form'] = $new_instance['show_form'];
        $instance['show_addr'] = $new_instance['show_addr'];
        $instance['phone'] = $new_instance['phone'];
        $instance['fax'] = $new_instance['fax'];
        $instance['email'] = $new_instance['email'];
        $instance['website'] = $new_instance['website'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $map = preg_replace('@width="[0-9]+"@is', 'width="100%"', $instance['map']);
        $add_one = $instance['add_one'];
        $add_two = $instance['add_two'];
        $show_map = $instance['show_map'];
        $show_form = $instance['show_form'];
        $show_addr = $instance['show_addr'];
        $phone = $instance['phone'];
        $fax = $instance['fax'];
        $email = $instance['email'];
        $website = $instance['website'];
        echo $before_widget;
        ?>
        <!--  =====  START GOOGLE MAP & CONTACT DETAILS  =====  -->
        <div class="row">
            <div class="span8">
                <?php if ($show_map): ?>
                    <div class="google_map">
                        <?php echo $map ?>
                    </div>
                <?php endif; ?>
                <?php if ($show_form): ?>
                    <form id="contact_page_form" method="POST" action="">
                        <div class="contact_form">
                            <input name="name" type="text" value="" placeholder="<?php _ex( 'Name (required)','contact-form','axa' ); ?>">
                            <input name="email" type="text" value="" placeholder="<?php _ex( 'Email (required)','contact-form','axa' ); ?>">
                            <input name="website" type="text" value="" placeholder="<?php _ex( 'WebSite','contact-form','axa' ); ?>">
                            <br/>
                            <textarea name="message" cols="10" rows="10" placeholder="<?php _ex( 'Message','contact-form','axa' ); ?>"></textarea>
                        </div>
                        <input type="hidden" value="<?php echo $email ?>" name="receiver_mail">
                        <input name="submit" type="submit" value="<?php _ex( 'Send','contact-form','axa' ); ?>" class="button l">
                    </form>
                    <div id="contact_page_form_result"></div>
                <?php endif; ?>
            </div>
            <div class="span4">
                <?php if ($show_addr): ?>
                    <div class="contact_info">
                        <p><b>Contact Info</b></p>
                        <p><?php echo $add_one ?><br/>
                            <?php echo $add_two ?><br/>
                        </p>
                        <?php if ($phone != '') : ?>
                            <p>Phone: <span class="color"><?php echo $phone ?></span><br/>
                            <?php endif; ?>
                            <?php if ($fax != '') : ?>
                                Fax: <span class="color"><?php echo $fax ?></span></p>
                            <?php endif; ?>
                            <?php if ($email != '') : ?>
                            <p>Email: <a href="mailto:<?php echo $email ?>"><?php echo $email ?></a><br/>
                            <?php endif; ?>
                            <?php if ($website != '') : ?>
                                Web: <a href="<?php echo $website ?>"><?php echo $website ?></a></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!--  =====  END GOOGLE MAP & CONTACT DETAILS  =====  -->
        <?php
        echo $after_widget;
    }
}

add_action('widgets_init', create_function('', 'return register_widget("MapAddrWidget");'));