<?php
/*
  Plugin Name: Testimonials Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays a quoted text and author
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class TestimonialsWidget extends WP_Widget {

    function TestimonialsWidget() {
        $widget_ops = array('classname' => 'TestimonialsWidget', 'description' => 'Displays a quoted text and author');
        $this->WP_Widget('TestimonialsWidget', '[AXA] Testimonials', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('text' => '', 'author' => '', 'company' => ''));
        $text = $instance['text'];
        $author = $instance['author'];
        $company = $instance['company'];
        ?>
        <p><label for="<?php echo $this->get_field_id('text'); ?>">Quote: <input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" type="text" value="<?php echo esc_attr($text); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('author'); ?>">Author: <input class="widefat" id="<?php echo $this->get_field_id('author'); ?>" name="<?php echo $this->get_field_name('author'); ?>" type="text" value="<?php echo esc_attr($author); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('company'); ?>">Company: <input class="widefat" id="<?php echo $this->get_field_id('company'); ?>" name="<?php echo $this->get_field_name('company'); ?>" type="text" value="<?php echo esc_attr($company); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['text'] = $new_instance['text'];
        $instance['author'] = $new_instance['author'];
        $instance['company'] = $new_instance['company'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);

        $text = empty($instance['text']) ? ' ' : apply_filters('widget_text', $instance['text']);
        $author = empty($instance['author']) ? ' ' : apply_filters('widget_author', $instance['author']);
        $company = empty($instance['company']) ? ' ' : apply_filters('widget_company', $instance['company']);

        if (!empty($text) && !empty($author) && !empty($company)) {
            ?>
            <div class='center_title'><span><?php _ex( 'What client\'s say','testimonials','axa' ); ?></span></div>
            <div class="testimonials">
            <?php echo $text ?>
                <div class="author"><span class="left_t"></span><?php echo $author ?>/<?php echo $company ?><span class="right_t"></span></div>
            </div>
            <?php
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("TestimonialsWidget");'));