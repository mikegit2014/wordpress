<?php
/*
  Plugin Name: Info
  Plugin URI: http://red-sky.pl/
  Description: Displays an info bar with social
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class InfoWidget extends WP_Widget {

    function InfoWidget() {
        $widget_ops = array('classname' => 'InfoWidget', 'description' => 'Displays an info bar with social');
        $this->WP_Widget('InfoWidget', '[AXA] Info with Social', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('text' => '', 'socialtext' => '', 'get_facebook' => false, 'get_skype' => false));
        $text = $instance['text'];
        $socialtext = $instance['socialtext'];
        $get_facebook = $instance['get_facebook'];
        $get_skype = $instance['get_skype'];
        $get_twitter = $instance['get_twitter'];
        $get_dribble = $instance['get_dribble'];
        $get_linkedin = $instance['get_linkedin'];
        ?>
        <p><label for="<?php echo $this->get_field_id('text'); ?>">Text: <input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" type="text" value="<?php echo esc_attr($text); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('socialtext'); ?>">Social Bar Text: <input class="widefat" id="<?php echo $this->get_field_id('socialtext'); ?>" name="<?php echo $this->get_field_name('socialtext'); ?>" type="text" value="<?php echo esc_attr($socialtext); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('get_facebook'); ?>"><input id="<?php echo $this->get_field_id('get_facebook'); ?>" name="<?php echo $this->get_field_name('get_facebook'); ?>" type="checkbox" value="1" <?php checked('1', $get_facebook); ?>/> Show facebook icon </label></p>
        <p><label for="<?php echo $this->get_field_id('get_skype'); ?>"><input id="<?php echo $this->get_field_id('get_skype'); ?>" name="<?php echo $this->get_field_name('get_skype'); ?>" type="checkbox" value="1" <?php checked('1', $get_skype); ?>/> Show skype icon </label></p>
        <p><label for="<?php echo $this->get_field_id('get_twitter'); ?>"><input id="<?php echo $this->get_field_id('get_twitter'); ?>" name="<?php echo $this->get_field_name('get_twitter'); ?>" type="checkbox" value="1" <?php checked('1', $get_twitter); ?>/> Show twitter icon </label></p>
        <p><label for="<?php echo $this->get_field_id('get_dribble'); ?>"><input id="<?php echo $this->get_field_id('get_dribble'); ?>" name="<?php echo $this->get_field_name('get_dribble'); ?>" type="checkbox" value="1" <?php checked('1', $get_dribble); ?>/> Show dribble icon </label></p>
        <p><label for="<?php echo $this->get_field_id('get_linkedin'); ?>"><input id="<?php echo $this->get_field_id('get_linkedin'); ?>" name="<?php echo $this->get_field_name('get_linkedin'); ?>" type="checkbox" value="1" <?php checked('1', $get_linkedin); ?>/> Show linkedin icon </label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['text'] = $new_instance['text'];
        $instance['socialtext'] = $new_instance['socialtext'];
        $instance['get_facebook'] = $new_instance['get_facebook'];
        $instance['get_skype'] = $new_instance['get_skype'];
        $instance['get_twitter'] = $new_instance['get_twitter'];
        $instance['get_dribble'] = $new_instance['get_dribble'];
        $instance['get_linkedin'] = $new_instance['get_linkedin'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $text = empty($instance['text']) ? ' ' : $instance['text'];
        $socialtext = empty($instance['socialtext']) ? ' ' : $instance['socialtext'];
        $get_facebook = $instance['get_facebook'];
        $get_skype = $instance['get_skype'];
        $get_twitter = $instance['get_twitter'];
        $get_dribble = $instance['get_dribble'];
        $get_linkedin = $instance['get_linkedin'];
        echo $before_widget;
        ?>
        <!--  =====  START INFORMATION  =====  -->
        <div class="information">
            <div class="info_text"><?php echo $text ?></div>
            <div class="get_social"><?php echo $socialtext ?>
                <?php if ($get_facebook) : ?>
                    <a href="<?php _e($options['fburl']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/facebook_c.png" alt="facebook" title="Facebook"></a>
                <?php endif; ?>
                <?php if ($get_skype) : ?>
                    <a href="skype:-<?php _e($options['skype_id']) ?>-?chat"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/skype_c.png" alt="skype" title="Skype"></a>
                <?php endif; ?>
                <?php if ($get_twitter) : ?>
                    <a href="http://twitter.com/<?php _e($options['twitterid']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/twitter_c.png" alt="twitter" title="Twitter"></a>
                <?php endif; ?>
                <?php if ($get_dribble) : ?>
                    <a href="http://dribbble.com/<?php _e($options['dribble_id']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/Dribbble_c.png" alt="Dribbble" title="Dribbble"></a>
                <?php endif; ?>
                <?php if ($get_linkedin) : ?>
                    <a href="<?php _e($options['linkedin_url']) ?>"><img class="tool_title" src="<?php bloginfo('template_url'); ?>/img/social/LinkedIn_c.png" alt="LinkedIn" title="LinkedIn"></a>
                <?php endif; ?>
            </div>
            <div class="clear"></div>
        </div>
        <!--  =====  END INFORMATION  =====  -->
        <?php
        echo $after_widget;
    }
}

add_action('widgets_init', create_function('', 'return register_widget("InfoWidget");'));