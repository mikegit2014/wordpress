<?php
/*
  Plugin Name: Twitter
  Plugin URI: http://red-sky.pl/
  Description: Displays Tweets
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class TwitterWidget extends WP_Widget {

    function TwitterWidget() {
        $widget_ops = array('classname' => 'TwitterWidget', 'description' => 'Displays Recent Tweets');
        $this->WP_Widget('TwitterWidget', '[AXA] Twitter', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('title' => 'Our Tweets', 'tweets_nr' => 5, 'twitterid'=>''));
        $title = $instance['title'];
        $tweets_nr = $instance['tweets_nr'];
        $twitterid = $instance['twitterid'];
        ?>
        <p><label for="<?php echo $this->get_field_id('title'); ?>">Title: <input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="title" value="<?php echo esc_attr($title); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('tweets_nr'); ?>">Nr of last tweets to show : <input class="widefat" id="<?php echo $this->get_field_id('tweets_nr'); ?>" name="<?php echo $this->get_field_name('tweets_nr'); ?>" type="title" value="<?php echo esc_attr($tweets_nr); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('twitterid'); ?>">Twitter ID:<input class="widefat" id="<?php echo $this->get_field_id('twitterid'); ?>" name="<?php echo $this->get_field_name('twitterid'); ?>" type="title" value="<?php echo esc_attr($twitterid); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['title'] = $new_instance['title'];
        $instance['tweets_nr'] = $new_instance['tweets_nr'];
        $instance['twitterid'] = $new_instance['twitterid'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $title = empty($instance['title']) ? 'Our Tweets' : $instance['title'];
        $tweets_nr = empty($instance['tweets_nr']) ? 9 : $instance['tweets_nr'];
        $twitterid = empty($instance['twitterid']) ? '' : $instance['twitterid'];
        echo $before_widget;
        ?>
        <div class="sidebar_title"><?php echo $title ?></div>
        <div class="twitter" data-user="<?php echo $twitterid ?>" data-posts="<?php echo $tweets_nr ?>"></div>
        <?php
        echo $after_widget;
    }
}

add_action('widgets_init', create_function('', 'return register_widget("TwitterWidget");'));