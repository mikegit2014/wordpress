<?php
/*
  Plugin Name: Main Slider Widget
  Plugin URI: http://red-sky.pl/
  Description: Displays our clients slider
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class MainSliderWidget extends WP_Widget {

    function MainSliderWidget() {
        $widget_ops = array('classname' => 'MainSliderWidget', 'description' => 'Displays main slider');
        $this->WP_Widget('MainSliderWidget', '[AXA] Main slider', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('hook' => ''));
        $hook = $instance['hook'];
        ?>
        <p><label for="<?php echo $this->get_field_id('hook'); ?>">Caption of images used for slider: <input class="widefat" id="<?php echo $this->get_field_id('hook'); ?>" name="<?php echo $this->get_field_name('hook'); ?>" type="text" value="<?php echo esc_attr($hook); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['hook'] = $new_instance['hook'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $hook = empty($instance['hook']) ? ' ' : apply_filters('widget_hook', $instance['hook']);
        global $mainslider;
        $mainslider = true;
        ?>
        <div class="slider">
            <div class="rs_mainslider">
                <ul class="rs_mainslider_items">
                    <?php
                    if (!empty($hook)) {
                        if (have_posts()) : while (have_posts()) : the_post();
                                $args = array(
                                    'post_type' => 'attachment',
                                    'numberposts' => -1,
                                    'orderby' => 'menu_order',
                                    'order' => 'ASC',
                                    'post_mime_type' => 'image',
                                    'post_status' => null,
                                    'post_parent' => get_the_ID()
                                );
                                $attachments = get_posts($args);
                                if ($attachments) {
                                    $i = 1;
                                    foreach ($attachments as $attachment) {
                                        if ($attachment->post_excerpt == $hook) {
                                            ?>
                                            <li <?php if ($i == 1) echo 'class="rs_mainslider_items_active"' ?>>
                                                <img class="rs_mainslider_items_image" src="<?php echo $attachment->guid ?>" />
                                                <div class="rs_mainslider_items_text">
                                                    <?php if ($attachment->post_title != "") : ?>
                                                        <span><a href="<?php echo get_permalink($attachment->post_parent); ?>"><?php echo $attachment->post_title ?></a></span>
                                                    <?php endif; ?>
                                                    <?php if (trim($attachment->post_content != "")) : ?>
                                                        <br /><span><a href="<?php echo get_permalink($attachment->post_parent); ?>"><?php echo $attachment->post_content ?></a></span>
                                <?php endif; ?>
                                                </div>
                                            </li>
                                            <?php
                                        }
                                        $i++;
                                    }
                                }
                            endwhile;
                        endif;
                        ?>
                    </ul>
                    <div class="rs_mainslider_left_container rs_center_vertical_container">
                        <div class="rs_mainslider_left rs_center_vertical"></div>
                    </div>
                    <div class="rs_mainslider_right_container rs_center_vertical_container">
                        <div class="rs_mainslider_right rs_center_vertical"></div>
                    </div>
                    <div class="rs_mainslider_dots_container rs_center_horizontal_container">
                        <ul class="rs_mainslider_dots rs_center_horizontal">
                        </ul>
                    </div>
                </div>
            </div>
            <?php
        }
    }

}

add_action('widgets_init', create_function('', 'return register_widget("MainSliderWidget");'));