<?php
/*
  Plugin Name: Call Us
  Plugin URI: http://red-sky.pl/
  Description: Displays a action_text number
  Author: Red-Sky
  Version: 1
  Author URI: http://red-sky.pl/
 */

class CallUsWidget extends WP_Widget {

    function CallUsWidget() {
        $widget_ops = array('classname' => 'CallUsWidget', 'description' => 'Displays a text or button linked to a page for contact');
        $this->WP_Widget('CallUsWidget', '[AXA] Get in touch', $widget_ops);
    }

    function form($instance) {
        $instance = wp_parse_args((array) $instance, array('text' => '', 'selector' => '', 'link' => '', 'action_text' => ''));
        $text = $instance['text'];
        $selector = $instance['selector'];
        $link = $instance['link'];
        $action_text = $instance['action_text'];
        $pages = get_pages();
        ?>
        <p><label for="<?php echo $this->get_field_id('text'); ?>">Text: <input class="widefat" id="<?php echo $this->get_field_id('text'); ?>" name="<?php echo $this->get_field_name('text'); ?>" type="text" value="<?php echo esc_attr($text); ?>" /></label></p>
        <p><label for="<?php echo $this->get_field_id('selector'); ?>">Type:
                <select class="widefat" id="<?php echo $this->get_field_id('selector'); ?>" name="<?php echo $this->get_field_name('selector'); ?>">
                    <option value="text"<?php if ($selector == 'text') _e(' selected="selected"') ?>>Text</option>
                    <option value="button"<?php if ($selector == 'button') _e(' selected="selected"') ?>>Button</option>
                </select>
            </label></p>
        <p><label for="<?php echo $this->get_field_id('link'); ?>">Link to:
                <select class="widefat" id="<?php echo $this->get_field_id('links'); ?>" name="<?php echo $this->get_field_name('link'); ?>">
                    <?php foreach ($pages as $page) : ?>
                        <option value="<?php echo get_page_link($page->ID)?>"<?php if (get_page_link($page->ID) == $link) _e(' selected="selected"') ?>><?php echo $page->post_title ?></option>
                    <?php endforeach; ?>
                </select>
            </label></p>
        <p><label for="<?php echo $this->get_field_id('action_text'); ?>">Action Text: <input class="widefat" id="<?php echo $this->get_field_id('action_text'); ?>" name="<?php echo $this->get_field_name('action_text'); ?>" type="text" value="<?php echo esc_attr($action_text); ?>" /></label></p>
        <?php
    }

    function update($new_instance, $old_instance) {
        $instance = $old_instance;
        $instance['text'] = $new_instance['text'];
        $instance['selector'] = $new_instance['selector'];
        $instance['link'] = $new_instance['link'];
        $instance['action_text'] = $new_instance['action_text'];
        return $instance;
    }

    function widget($args, $instance) {
        extract($args, EXTR_SKIP);
        $text = empty($instance['text']) ? ' ' : apply_filters('widget_text', $instance['text']);
        $selector = empty($instance['selector']) ? ' ' : apply_filters('widget_selector', $instance['selector']);
        $action_text = empty($instance['action_text']) ? ' ' : apply_filters('widget_action_text', $instance['action_text']);
        $link = empty($instance['link']) ? ' ' : apply_filters('widget_link', $instance['link']);
        if (!empty($text) && !empty($action_text)) {
            echo $before_widget;
            ?>
            <div class="callus"><?php echo $text ?>
                <span>
                    <?php
                    if ($selector == 'text')
                        echo $action_text;
                    else
                        echo '<a href="' . $link . '" class="button">' . $action_text . '</a>';
                    ?>
                </span>
            </div>
            <?php
            echo $after_widget;
        }
    }
}

add_action('widgets_init', create_function('', 'return register_widget("CallUsWidget");'));